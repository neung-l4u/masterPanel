SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


DROP TABLE IF EXISTS `CoinActivities`;
CREATE TABLE `CoinActivities` (
  `aID` tinyint(4) UNSIGNED NOT NULL,
  `aName` varchar(100) NOT NULL,
  `aStatus` tinyint(4) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci COMMENT='Activity to earn coin';

INSERT INTO `CoinActivities` (`aID`, `aName`, `aStatus`) VALUES
(1, 'Company Award', 1),
(2, 'Company Event', 1),
(3, 'Convince to send SMS', 1),
(4, 'Upgrade to MKT', 1),
(5, 'Add line Official', 1),
(6, 'Referrals', 1),
(7, 'Book an Appointment for Sales', 1),
(8, 'Google Review', 1),
(9, 'IHD', 1),
(10, 'Convert Coin by user', 1),
(11, 'Other', 1),
(12, 'Redeem for gift', 1),
(13, 'Transfer to friend', 1);

DROP TABLE IF EXISTS `CoinLogs`;
CREATE TABLE `CoinLogs` (
  `id` int(10) UNSIGNED NOT NULL,
  `coinType` tinyint(3) UNSIGNED NOT NULL COMMENT '1=L4U, 2=CEO',
  `ownerID` tinyint(3) UNSIGNED NOT NULL COMMENT 'user ID',
  `amount` float NOT NULL DEFAULT 0 COMMENT 'float',
  `giveBy` tinyint(3) UNSIGNED NOT NULL COMMENT 'user ID',
  `activityID` tinyint(3) UNSIGNED DEFAULT NULL,
  `reason` text NOT NULL,
  `giveOn` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'date time',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'boolean',
  `lastUpdate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp() COMMENT 'date time'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `CoinLogs` (`id`, `coinType`, `ownerID`, `amount`, `giveBy`, `activityID`, `reason`, `giveOn`, `status`, `lastUpdate`) VALUES
(1, 2, 38, 2, 1, 1, 'The Rising Star Of The Year Award -  2023', '2024-01-02 15:17:44', 1, '2024-02-13 09:17:33'),
(2, 2, 31, 2, 1, 1, 'The Healthiest Award - 2023', '2024-01-02 15:18:42', 1, '2024-02-13 09:17:33'),
(3, 2, 30, 2, 1, 1, 'The Healthiest Award - 2023', '2024-01-02 15:19:39', 1, '2024-02-13 09:17:33'),
(4, 2, 28, 2, 1, 1, 'The Extra Mile Award - 2023', '2024-01-02 15:20:39', 1, '2024-02-13 09:17:33'),
(5, 2, 16, 2, 1, 1, 'The Team Player Of The Year Award - 2023', '2024-01-02 15:21:41', 1, '2024-02-13 09:17:33'),
(6, 2, 41, 2, 1, 1, 'The Fast Starter Award - 2023', '2024-01-02 15:22:29', 1, '2024-02-13 09:17:33'),
(7, 2, 35, 2, 1, 1, 'Top Sale Of The Year Award - 2023', '2024-01-02 15:23:12', 1, '2024-02-13 09:17:33'),
(8, 2, 34, 2, 1, 1, 'The Fast Learner Award - 2023', '2024-01-02 15:24:02', 1, '2024-02-13 09:17:33'),
(9, 2, 42, 2, 1, 1, 'The Loyalty Award - 2023', '2024-01-02 15:24:47', 1, '2024-02-13 09:17:33'),
(10, 2, 17, 1, 1, 2, '2023 Event Winners - Marketing Campaign Competition', '2024-01-02 15:29:43', 1, '2024-02-13 09:17:34'),
(11, 2, 38, 1, 1, 2, '2023 Event Winners - Marketing Campaign Competition', '2024-01-02 15:30:00', 1, '2024-02-13 09:17:34'),
(12, 2, 24, 1, 1, 2, '2023 Event Winners - Marketing Campaign Competition', '2024-01-02 15:30:15', 1, '2024-02-13 09:17:34'),
(13, 1, 36, 1, 1, 3, 'SMS: Assist them to send SMS (พี่อชิ Yumm Thai Wallsend)#1', '2024-01-11 07:56:11', 1, '2024-02-13 09:17:34'),
(14, 1, 36, 1, 1, 3, 'SMS: Assist them to send SMS (พี่อชิ Yumm Thai Wallsend)#2', '2024-01-11 07:56:26', 1, '2024-02-13 09:17:34'),
(15, 1, 36, 1, 1, 4, 'Upgrade to MKT: Make an appoitment for marketing upgrade (Udom Thai)', '2024-01-11 07:56:42', 1, '2024-02-13 09:17:34'),
(16, 1, 36, 1, 1, 6, 'Referrals: Great news Vachiraporn Potikul พี่โอน! Your appointment is booked for Friday, January 12, 2024, 3:00 PM (Australia/Victoria).', '2024-01-11 07:56:54', 1, '2024-02-13 09:17:35'),
(17, 1, 41, 1, 1, 5, 'Add to LINE Official: Add Line during LIVE session (Princess Thai Massage & Spa)', '2024-01-11 07:57:52', 1, '2024-02-13 09:17:34'),
(18, 1, 21, 1, 1, 5, 'Add to LINE Official: she might interested website booking system (Khun Siam Thai Massage)', '2024-01-11 07:58:09', 1, '2024-02-13 09:17:34'),
(19, 1, 38, 1, 1, 5, 'Add to LINE Official: she might interested website booking system (New Day Thai Massage)', '2024-01-11 08:11:06', 1, '2024-02-13 09:17:34'),
(20, 1, 20, 1, 1, 5, 'Add to LINE Official : (Senyai Thai Steetfood)', '2024-01-15 03:35:42', 1, '2024-02-13 09:17:34'),
(21, 1, 34, 1, 1, 6, 'Referrals: K\'Ning, the former manager of The Nine Thai Cuisine (canceled their services last year), referred this shop to us. When K\'Ning canceled, she mentioned that she would recommend our services to other restaurants. (Pad thai Cuisine)', '2024-01-15 03:37:35', 1, '2024-02-13 09:17:35'),
(22, 1, 41, 1, 1, 7, 'Book an appointment for sale: Friday, January 12, 2024, 2:00 PM (Australia/Queensland). (Thai Topia Street Food Kitchen)', '2024-01-15 03:38:28', 1, '2024-02-13 09:17:35'),
(23, 1, 36, 1, 1, 7, 'Book an appointment for sales: Monday, January 15, 2024, 4:00 PM (Australia/Victoria). (Cattleya Thai (Warrnambool))', '2024-01-15 03:38:58', 1, '2024-02-13 09:17:35'),
(24, 1, 24, 1, 1, 5, 'Add to LINE Official: (Pad Thai cuisine)', '2024-01-15 04:05:01', 1, '2024-02-13 09:17:35'),
(32, 1, 26, 1, 31, 6, 'Referrals', '2024-01-23 00:38:57', 1, '2024-02-13 09:17:35'),
(33, 1, 26, 1, 31, 4, 'Upgrade to MKT', '2024-01-23 00:39:38', 1, '2024-02-13 09:17:34'),
(34, 1, 34, 1, 31, 4, 'Upgrade to MKT or Website | This account signed up for add-on: Social Media Management (Posts) $49, starting from billing Jan 25, 2024.', '2024-01-23 00:40:48', 1, '2024-02-13 09:17:34'),
(35, 1, 34, 1, 31, 4, 'Upgrade to MKT or Website | This account signed up for add-on: Social Media Management (Posts) $49, starting from billing Jan 25, 2024.', '2024-01-23 00:41:31', 1, '2024-02-13 09:17:34'),
(36, 1, 34, 1, 31, 6, 'Ask customer for Referrals | Smile customer', '2024-01-23 00:42:26', 1, '2024-02-13 09:17:35'),
(37, 1, 34, 1, 31, 8, 'Google Review | Houston Thai Massage & Spa', '2024-01-23 00:43:23', 1, '2024-02-13 09:17:35'),
(38, 1, 15, 1, 42, 9, 'IHD', '2024-01-25 07:14:55', 1, '2024-02-13 09:17:35'),
(39, 1, 15, 1, 42, 5, 'Add to LINE Official', '2024-01-25 07:16:08', 1, '2024-02-13 09:17:35'),
(40, 1, 15, 1, 42, 4, 'Upgrade to MKT or Website', '2024-01-25 07:18:50', 1, '2024-02-13 09:17:34'),
(41, 1, 39, 1, 31, 8, 'Google Review - Chili Basil Thai Cuisine', '2024-01-26 18:55:15', 1, '2024-02-13 09:17:35'),
(42, 1, 41, 1, 13, 4, 'De Rest Thai massage upgrade to marketing', '2024-01-29 02:58:20', 1, '2024-02-13 09:17:35'),
(43, 1, 41, 1, 13, 9, 'explained to P\' Aoi how IHD works. She has agreed to use IHD during the first call on Google Meet', '2024-01-29 03:00:33', 1, '2024-02-13 09:17:35'),
(44, 1, 36, 1, 13, 4, 'Upgrade to marketing - ค้นแชทที่เลื่อนผ่านของลูกค้าและสอบถามด้าน Marketing appointment เข้าไปอีกรอบ', '2024-01-29 03:19:01', 1, '2024-02-13 09:17:34'),
(45, 1, 46, 1, 13, 8, 'The review does not appear on Google, but the restaurant has sent proof. Use as testimonial\nhttps://drive.google.com/file/d/176HM5GkL63-koxJ3v1Sj6_1H9OFJHLpm/view?usp=sharing', '2024-01-29 03:22:07', 1, '2024-02-13 09:17:35'),
(46, 1, 41, 1, 13, 6, 'Ask to grab up their interest on clicked the ads and book an appoitment for sales for signup and marketing ', '2024-01-29 04:43:56', 1, '2024-02-13 09:17:35'),
(47, 1, 12, 1, 13, 4, 'Marketing Interested', '2024-02-13 03:28:15', 1, '2024-02-13 09:17:34'),
(48, 1, 34, 1, 31, 6, 'Ask customer for Referrals | Little Tonnam Thai', '2024-02-13 17:22:05', 1, '2024-02-22 00:39:57'),
(49, 1, 34, 1, 31, 9, 'IHD | Tonnam Thai Kitchen', '2024-02-13 17:54:19', 1, '2024-02-22 00:39:54'),
(50, 1, 34, 1, 31, 4, 'Upgrade to MKT or Website | We Are Thai Massage', '2024-02-13 17:55:43', 1, '2024-02-22 00:39:49'),
(51, 1, 34, 1, 31, 8, 'Google Review | SENYAI Thai Street food & Noodle Bar', '2024-02-13 17:56:58', 1, '2024-02-22 00:38:35'),
(53, 1, 34, 0, 31, 8, 'Google Review | SENYAI Thai Street food & Noodle Bar | put in wrong staff', '2024-02-23 19:15:36', 1, NULL),
(54, 1, 39, 1, 31, 8, 'SENYAI Thai Street food & Noodle Bar', '2024-02-23 19:16:06', 1, NULL),
(55, 1, 46, 1, 13, 5, 'Google Review for Thai House Chinchilla https://drive.google.com/open?id=1S8pMnL4I4wxaQhm3GHRcCsOXUsUxWTj2', '2024-02-27 06:30:32', 1, NULL),
(56, 1, 37, 1, 13, 4, 'Upgrade from GF complementary website to be website\'s template ', '2024-02-27 06:33:19', 1, NULL),
(57, 1, 30, 1, 13, 1, 'Convinced customers to use Stripe for their massage booking system', '2024-02-27 06:36:36', 1, NULL),
(58, 1, 19, 1, 13, 9, 'invite to use IHD', '2024-02-27 06:37:34', 1, NULL),
(59, 1, 46, 1, 13, 1, 'Take picture with Local for you sticker\nhttps://drive.google.com/file/d/1l7gNSzXoXbRnh026JZ4IAeaPMcabuh1e/view', '2024-02-27 06:50:52', 1, NULL),
(60, 1, 24, 4, 17, 5, 'Line', '2024-03-05 04:05:36', 1, NULL),
(61, 1, 20, 7, 17, 5, 'IHD too', '2024-03-05 04:05:57', 1, NULL),
(62, 1, 21, 1, 17, 5, 'Line', '2024-03-05 04:06:20', 1, NULL),
(63, 1, 21, 6, 17, 5, 'Line', '2024-03-05 04:07:25', 1, NULL),
(64, 1, 35, 8, 17, 5, 'Line', '2024-03-05 04:08:12', 1, NULL),
(65, 1, 38, 5, 17, 5, 'Line', '2024-03-05 04:08:28', 1, NULL),
(66, 1, 46, 1, 13, 1, 'Auto - pilot', '2024-03-06 02:04:12', 1, NULL),
(67, 1, 46, 1, 13, 1, 'Auto pilot - a day in bkk william town', '2024-03-06 02:04:36', 1, NULL),
(68, 1, 46, 1, 13, 8, 'Google review Yodthai restaurant', '2024-03-06 02:05:49', 1, NULL),
(69, 1, 46, 1, 13, 9, 'Inhouse delivery for Baan phaya thai Everton', '2024-03-06 02:06:25', 1, NULL),
(70, 1, 39, 1, 31, 6, 'Ask customer for Referrals - Chili Basil Thai Cuisine', '2024-03-13 19:23:17', 1, NULL),
(71, 1, 15, 1, 49, 1, 'First Quarterly Company game', '2024-03-21 00:29:12', 1, NULL),
(72, 1, 16, 1, 49, 1, 'First Quarterly Company game', '2024-03-21 00:29:19', 1, NULL),
(73, 1, 28, 1, 49, 1, 'First Quarterly Company game', '2024-03-21 00:29:25', 1, NULL),
(74, 1, 32, 1, 49, 1, 'First Quarterly Company game', '2024-03-21 00:29:29', 1, NULL),
(75, 1, 33, 1, 49, 1, 'First Quarterly Company game', '2024-03-21 00:29:33', 1, NULL),
(76, 1, 34, 1, 49, 1, 'First Quarterly Company game', '2024-03-21 00:29:37', 1, NULL),
(77, 1, 39, 1, 49, 1, 'First Quarterly Company game', '2024-03-21 00:29:41', 1, NULL),
(78, 1, 26, 1, 49, 1, 'First Quarterly Company game', '2024-03-21 00:29:46', 1, NULL),
(79, 1, 31, 1, 49, 6, 'Ask the customer for Referrals, Sphere Nails Bar', '2024-03-21 00:32:47', 1, NULL),
(80, 1, 31, 1, 49, 1, 'Convinced customers to use Stripe for their massage booking system Siam Thai Massage and Spa', '2024-03-21 00:33:16', 1, NULL),
(81, 1, 39, 2, 31, 6, 'Ask customer for Referrals | We Are Thai Massage referred Cleopatra Spa & Massage | Get double coins', '2024-03-29 20:30:43', 1, NULL),
(82, 1, 34, 1, 31, 9, 'IHD | C U at THAI Restaurant ', '2024-03-29 20:34:36', 1, NULL),
(83, 1, 23, 2, 13, 1, 'Team meeting Q &A', '2024-04-08 06:29:59', 1, NULL),
(84, 1, 23, 1, 13, 5, 'Contact through website > infomed to add LINE', '2024-04-17 05:54:30', 1, NULL),
(85, 1, 41, 1, 13, 8, 'This review is from a customer of Thaiger Dine In & Takeaway. They shared their experience on posts that I shared on the page. https://drive.google.com/open?id=1beJZmAMPlJ-OPsihMZbGU8DvB8gez5XO', '2024-04-17 05:55:45', 1, NULL),
(86, 1, 41, 1, 13, 9, 'This restaurant is not interested in using IHD service when signing up because the fees are very high. They prefer to find their own delivery driver. I tried to explain how it works and what is included in the fee, and finally, she agreed to use IHD.', '2024-04-17 05:56:22', 1, NULL),
(87, 1, 37, 1, 13, 9, 'change Doordash intregration to IHD', '2024-04-17 05:57:15', 1, NULL),
(88, 1, 36, 1, 13, 9, 'Setup IHD account - Pookie', '2024-04-17 05:57:37', 1, NULL),
(89, 1, 36, 1, 13, 9, 'Created IHD account and areas for new sign up thai eat box hill - Pookie', '2024-04-17 05:58:44', 1, NULL),
(90, 1, 30, 1, 13, 9, 'Created IHD account and monitored orders after launch', '2024-04-17 05:59:50', 1, NULL),
(91, 1, 41, 1, 13, 8, 'https://drive.google.com/open?id=1rukCO-DxbtEdKUhfoVDwrHCA1QYqG4Sh', '2024-04-17 06:00:30', 1, NULL),
(92, 1, 62, 1, 17, 5, 'Line', '2024-05-02 08:24:14', 1, NULL),
(93, 1, 21, 7, 17, 5, 'Line', '2024-05-02 08:28:17', 1, NULL),
(94, 1, 24, 1, 17, 5, 'Line', '2024-05-02 08:28:44', 1, NULL),
(95, 1, 35, 2, 17, 5, 'Line', '2024-05-02 08:29:04', 1, NULL),
(96, 1, 38, 2, 17, 5, 'Line', '2024-05-02 08:29:30', 1, NULL),
(97, 1, 30, 1, 13, 9, 'Persuade to use IHD', '2024-05-23 00:40:36', 1, NULL),
(98, 1, 36, 1, 13, 9, 'Explained the fees and area coverage and why it is better than doing Uberdirect. Setup account and tested order. ', '2024-05-23 00:41:14', 1, NULL),
(99, 1, 36, 1, 13, 4, 'I upsell website makeover when the client was thinking to do it with outside developer. Now she upgraded to marketing with offered website makeover from Sales. ', '2024-05-23 00:43:42', 1, NULL),
(100, 1, 15, 1, 42, 4, 'Auto Pilot	Little Thai', '2024-05-23 03:23:54', 1, NULL),
(101, 1, 15, 1, 42, 8, 'Google Review:Blue Buddha Thai', '2024-05-23 03:24:25', 1, NULL),
(102, 1, 15, 1, 42, 9, 'IHD	Daisy Thai', '2024-05-23 03:24:45', 1, NULL),
(103, 1, 28, 1, 42, 8, 'Google Review	- Chiao\'s cafe', '2024-05-23 03:25:22', 1, NULL),
(104, 1, 28, 1, 42, 6, 'Ask customer for Referrals	: Thai Ra We > Little Thai', '2024-05-23 03:25:53', 1, NULL),
(105, 1, 33, 1, 42, 8, 'Google Review	: Chok Chai Thai Restaurant', '2024-05-23 03:26:15', 1, NULL),
(106, 1, 33, 1, 42, 8, 'Google Review-Village Thai Cuisine', '2024-05-23 03:27:01', 1, NULL),
(107, 1, 15, 1, 42, 5, 'Add to LINE Official (for non-customer only):The blend sand cospa and salon ', '2024-05-23 03:27:27', 1, NULL),
(108, 1, 15, 1, 42, 3, ':Little Thai Place', '2024-05-23 03:28:13', 1, NULL),
(109, 1, 15, 1, 42, 3, 'The Zest\'s Garden Thai Cuisine', '2024-05-23 03:28:29', 1, NULL),
(110, 1, 16, 1, 42, 8, 'Gungahlin Thai Remedial Massage', '2024-05-23 03:29:08', 1, NULL),
(111, 1, 36, 1, 13, 4, 'I persuaded the owner into doing Marketing right after the restaurant live Pro Plan. The restaurant is now doing 3 month-social media marketing with us. ', '2024-05-29 01:20:02', 1, NULL),
(112, 1, 15, 10, 42, 2, 'Manager Coin - May : Google Certificate', '2024-05-29 04:45:09', 1, NULL),
(113, 1, 39, 1, 31, 6, 'Spicy Tuna', '2024-05-29 23:31:08', 1, NULL),
(114, 1, 34, 1, 31, 8, 'Chachawan (Queens, NY)', '2024-05-29 23:32:28', 1, NULL),
(115, 1, 34, 1, 31, 4, 'Momo Tea Bar', '2024-05-29 23:33:29', 1, NULL),
(116, 1, 39, 3, 31, 1, 'Manager task: Google Course', '2024-05-29 23:35:46', 1, NULL),
(117, 1, 26, 3, 31, 1, 'Manager task: Completed AI-Power Shopping ads Certification', '2024-05-29 23:36:29', 1, NULL),
(118, 1, 34, 3, 31, 1, 'Manager task: Google Course', '2024-05-29 23:38:29', 1, NULL),
(119, 1, 23, 1, 13, 2, 'Convinced customers to use Stripe for their massage booking system', '2024-06-03 01:26:44', 1, NULL),
(120, 1, 21, 3, 17, 5, 'Add Line', '2024-06-03 01:31:19', 1, NULL),
(121, 1, 20, 3, 17, 5, 'Add Line', '2024-06-03 01:31:50', 1, NULL),
(122, 1, 35, 12, 17, 5, 'Add Line', '2024-06-03 01:33:39', 1, NULL),
(123, 1, 38, 1, 17, 5, 'Line', '2024-06-03 01:34:33', 1, NULL),
(124, 1, 24, 1, 17, 5, 'Line', '2024-06-03 01:34:44', 1, NULL),
(125, 1, 62, 1, 17, 5, 'Line', '2024-06-03 01:35:00', 1, NULL),
(126, 1, 21, 6, 17, 5, 'Line', '2024-06-03 01:39:07', 1, NULL),
(127, 1, 27, 1, 1, 11, 'Completed Urgent task Sa-biang Thai Restaurant', '2024-05-08 22:01:23', 1, '2024-06-04 22:58:59'),
(128, 1, 14, 1, 1, 11, 'Completed Urgent task Bangkok Thai Chevron', '2024-05-17 22:04:43', 1, '2024-06-04 22:58:54'),
(129, 1, 60, 1, 1, 11, 'Completed Urgent Task Thai Topia', '2024-06-03 22:06:04', 1, '2024-06-04 22:58:50'),
(130, 1, 48, 1, 1, 11, 'Completed Urgent Task Voucher system', '2024-05-27 22:09:46', 1, '2024-06-04 22:10:07'),
(131, 1, 14, 1, 1, 11, 'Sacrificing vacation time April', '2024-04-29 22:11:39', 1, '2024-06-04 22:14:01'),
(132, 1, 14, 1, 1, 11, 'Sacrificing vacation time May', '2024-05-30 22:11:54', 1, '2024-06-04 22:14:14'),
(133, 1, 50, 1, 1, 11, 'Complete Urgent task Coin system', '2024-04-16 22:13:26', 1, '2024-06-04 22:14:25'),
(134, 1, 1, 1, 1, 11, 'x2 event', '2024-06-06 02:15:44', 1, NULL),
(135, 1, 12, 1, 1, 11, 'x2 event', '2024-06-06 02:15:44', 1, NULL),
(136, 1, 13, 1, 1, 11, 'x2 event', '2024-06-06 02:15:44', 1, NULL),
(137, 1, 14, 3, 1, 11, 'x2 event', '2024-06-06 02:15:44', 1, NULL),
(138, 1, 15, 20, 1, 11, 'x2 event', '2024-06-06 02:15:44', 1, NULL),
(139, 1, 16, 2, 1, 11, 'x2 event', '2024-06-06 02:15:44', 1, NULL),
(140, 1, 17, 1, 1, 11, 'x2 event', '2024-06-06 02:15:44', 1, NULL),
(141, 1, 19, 1, 1, 11, 'x2 event', '2024-06-06 02:15:44', 1, NULL),
(142, 1, 20, 11, 1, 11, 'x2 event', '2024-06-06 02:15:44', 1, NULL),
(143, 1, 21, 24, 1, 11, 'x2 event', '2024-06-06 02:15:44', 1, NULL),
(144, 1, 22, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(145, 1, 23, 4, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(146, 1, 24, 7, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(147, 1, 25, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(148, 1, 26, 6, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(149, 1, 27, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(150, 1, 28, 3, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(151, 1, 29, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(152, 1, 30, 3, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(153, 1, 31, 2, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(154, 1, 32, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(155, 1, 33, 3, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(156, 1, 34, 15, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(157, 1, 35, 22, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(158, 1, 36, 11, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(159, 1, 37, 2, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(160, 1, 38, 9, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(161, 1, 39, 10, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(162, 1, 41, 8, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(163, 1, 42, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(164, 1, 43, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(165, 1, 44, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(166, 1, 45, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(167, 1, 46, 7, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(168, 1, 47, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(169, 1, 48, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(170, 1, 49, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(171, 1, 50, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(172, 1, 60, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(173, 1, 61, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(174, 1, 62, 2, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(175, 1, 63, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(176, 1, 64, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(177, 1, 65, 1, 1, 11, 'x2 event', '2024-06-06 02:15:45', 1, NULL),
(178, 2, 14, 2, 1, 2, 'Steve give special reward form 2nd company meeting 2024', '2024-06-06 02:21:51', 1, NULL),
(179, 2, 41, 2, 1, 1, 'Steve give special reward form 2nd company meeting 2024', '2024-06-06 02:22:34', 1, NULL),
(180, 2, 17, 2, 1, 1, 'Steve give special reward form 2nd company meeting 2024', '2024-06-06 02:23:03', 1, NULL),
(181, 2, 42, 2, 1, 1, 'Steve give special reward form 2nd company meeting 2024', '2024-06-06 02:25:51', 1, NULL),
(182, 2, 35, 2, 1, 1, 'Steve give special reward form 2nd company meeting 2024', '2024-06-06 02:29:03', 1, NULL),
(183, 2, 21, 1, 1, 1, 'Employee of the quarter form 2nd company meeting 2024', '2024-06-06 02:41:18', 1, NULL),
(184, 1, 34, 7, 31, 11, 'Manager task: Google Course', '2024-06-07 00:44:39', 1, NULL),
(185, 1, 36, -20, 36, 11, 'Redeem for day off', '2024-06-07 00:55:49', 1, NULL),
(186, 1, 65, 1, 31, 4, 'Upgrade from solo to bundle: Lekda Thai Massage', '2024-06-18 22:29:45', 1, NULL),
(187, 1, 65, 1, 31, 4, 'Upgrade from solo to bundle: Wasana Thai Massage UK', '2024-06-18 22:30:28', 1, NULL),
(188, 1, 39, 1, 31, 4, 'Realthaikitchen@ The Dome Bar UK: upgrade from MKT solo to bundle', '2024-07-05 16:01:40', 1, NULL),
(189, 1, 39, 7, 31, 11, 'Manager task: Google Course', '2024-07-05 16:02:21', 1, NULL),
(190, 2, 28, 20, 28, 10, 'CEO to L4U', '2024-07-29 05:43:52', 1, NULL),
(191, 1, 28, -20, 28, 10, 'Redeem to cash', '2024-07-29 05:44:08', 1, NULL),
(192, 1, 26, 7, 31, 11, 'Manager task', '2024-08-01 22:32:13', 1, NULL),
(193, 1, 39, 1, 31, 4, 'Tuk-Tuk Thai Kitchen USA: add post $49', '2024-08-01 22:33:21', 1, NULL),
(194, 1, 34, 2, 31, 6, 'Early Owl referred by Yuma Ramen', '2024-08-01 22:35:12', 1, NULL),
(195, 1, 15, 1, 42, 4, 'Convinced the restaurant to do marketing from direct 3 months, to mega 12 months', '2024-08-06 02:01:04', 1, NULL),
(196, 1, 15, 1, 42, 11, 'Testimonial about Local For You from True Thai restaurant expressing that the owner is very happy with Local For You and will not be changing to any other company', '2024-08-06 02:01:25', 1, NULL),
(197, 1, 15, 1, 42, 3, 'Encouraged owner to send SMS to promote promotion, it helps increase sales very well. She agreed to do so. ', '2024-08-06 02:01:39', 1, NULL),
(198, 1, 19, 1, 13, 9, 'Encorage using IHD', '2024-08-06 03:36:33', 1, NULL),
(199, 1, 23, 1, 13, 5, 'Non exsiting to sales', '2024-08-06 03:37:34', 1, NULL),
(200, 1, 46, 1, 13, 11, 'convince to use stripe for massage ', '2024-08-06 03:39:47', 1, NULL),
(201, 1, 46, 1, 13, 11, 'Convince to use stripe for massage', '2024-08-06 03:41:06', 1, NULL),
(202, 1, 19, 1, 13, 11, '\"I called the restaurant owner and explained her how auto-pilot works and the conditions of each campaign.\nShe is interested in using auto-pilot.\n\nSo I activated auto-pilot and set up the promotions with her on the call.\nAuto pilot of this restaurant is now LIVE.\"', '2024-08-06 03:46:17', 1, NULL),
(203, 1, 12, 1, 13, 8, 'https://drive.google.com/file/d/13JzGX96d4DgQP4JnSNZgHkXNQZR9mDoL/view', '2024-08-06 03:46:51', 1, NULL),
(204, 1, 41, 1, 13, 3, 'Convinced customer to send out SMS or help set up for the first time\n\nI have discussed with K. Aong about sending an SMS and upgrading to MKT. He informed me about the rebranding and expressed a desire to send a promotion to customers for the reopening. We have agreed to send the SMS.', '2024-08-06 03:47:54', 1, NULL),
(205, 1, 19, 1, 13, 11, 'Auto pilot - Auto-pilot of this restaurant is now LIVE as there is a new owner rejoined as Pro plan. They are also interested in upgrading to Marketing during the live process.', '2024-08-06 03:48:59', 1, NULL),
(206, 1, 19, 1, 13, 11, 'Auto pilot - 1st time purchased', '2024-08-06 03:49:30', 1, NULL),
(207, 1, 36, 1, 13, 1, 'Auto-pilot Persuaded and helped answer questions as well as activated the re-engage client campaign.', '2024-08-06 03:49:56', 1, NULL),
(208, 1, 23, 1, 13, 4, 'Ranproad', '2024-08-06 03:50:31', 1, NULL),
(209, 1, 23, 1, 13, 9, 'Baan phayathai dakabin', '2024-08-06 03:50:56', 1, NULL),
(210, 1, 30, 1, 13, 11, 'Stripe - Convinced customers to use Stripe for their massage booking system', '2024-08-06 03:51:27', 1, NULL),
(211, 1, 46, 1, 13, 11, 'Stripe for massage Sabai Gaya Thai Massage Liverpool Street', '2024-08-06 03:52:45', 1, NULL),
(212, 1, 46, 1, 13, 11, 'Stripe for massage - Sabai Gaya Thai massage South kensington', '2024-08-06 03:53:04', 1, NULL),
(213, 1, 20, 3, 17, 5, 'Line', '2024-08-13 01:32:45', 1, NULL),
(214, 1, 21, 3, 17, 5, 'Line', '2024-08-13 01:32:59', 1, NULL),
(215, 1, 61, 1, 17, 5, 'Line', '2024-08-13 01:33:30', 1, NULL),
(216, 1, 35, -40, 35, 10, 'Redeem to cash', '2024-08-16 04:46:32', 1, NULL),
(217, 2, 35, 40, 35, 10, 'CEO to L4U', '2024-08-16 04:47:43', 1, NULL),
(218, 1, 35, -40, 35, 10, 'Redeem to cash', '2024-08-16 04:47:51', 1, NULL),
(219, 1, 21, -50, 21, 10, 'Redeem to cash', '2024-08-16 14:37:30', 1, NULL),
(220, 1, 32, 1, 42, 11, 'win activity Guess what\'s behind the blanket? ', '2024-08-20 04:56:53', 1, NULL),
(221, 1, 15, -20, 15, 10, 'Redeem to cash', '2024-08-22 02:32:19', 1, NULL),
(222, 1, 21, 3, 17, 5, 'Line', '2024-08-30 02:56:18', 1, NULL),
(223, 1, 20, 4, 17, 5, 'Add line', '2024-08-30 02:56:34', 1, NULL),
(224, 1, 21, 6, 17, 11, 'August Challenge: Social Media Appointment ', '2024-08-30 02:58:12', 1, NULL),
(225, 1, 38, 2, 17, 11, 'August Challenge: Social Media Appointment ', '2024-08-30 02:58:26', 1, NULL),
(226, 1, 21, 1, 17, 11, 'August Challenge: Social Media Appointment ', '2024-08-30 03:01:54', 1, NULL),
(227, 1, 61, 1, 17, 11, 'August Challenge: Social Media Appointment ', '2024-08-30 03:02:03', 1, NULL),
(228, 1, 46, 2, 17, 11, 'Lead to The Moon', '2024-08-30 03:16:41', 1, NULL),
(229, 1, 32, 1, 17, 11, 'Lead to The Moon', '2024-08-30 03:17:43', 1, NULL),
(230, 2, 34, 20, 34, 10, 'CEO to L4U', '2024-09-03 23:03:05', 1, NULL),
(231, 1, 15, 1, 42, 9, '- Muang thong gold city', '2024-09-04 02:24:18', 1, NULL),
(232, 1, 33, 1, 42, 8, 'Thai malila oxley', '2024-09-04 02:26:06', 1, NULL),
(233, 1, 33, 1, 42, 8, 'Google review - Strictly Thai Restaurant', '2024-09-04 02:27:09', 1, NULL),
(234, 1, 15, 1, 42, 6, 'referrals  from the zest - Water lilly', '2024-09-04 02:29:42', 1, NULL),
(235, 1, 15, 2, 17, 11, 'Lead To The Moon', '2024-09-04 08:19:34', 1, NULL),
(236, 1, 34, 1, 17, 11, 'Lead To The Moon', '2024-09-04 08:19:48', 1, NULL),
(237, 1, 30, 1, 13, 9, 'Rosebud thai restaurant', '2024-09-16 02:56:03', 1, NULL),
(238, 1, 36, 1, 13, 8, 'Super fast service and professional\nKi, Kam and Aim are the best helping me solve the problem since create the website, do the advertising also setup all payment program.  Thank you so much Localforyou. !!!\n', '2024-09-16 02:58:04', 1, NULL),
(239, 1, 12, 1, 13, 11, 'Massage Stripe', '2024-09-16 02:58:52', 1, NULL),
(240, 1, 12, 1, 13, 8, 'Super fast service and professional\nKi, Kam and Aim are the best helping me solve the problem since create the website, do the advertising also setup all payment program.  Thank you so much Localforyou. !!!\n', '2024-09-16 02:59:15', 1, NULL),
(241, 1, 36, 1, 13, 9, 'Resebud IHD', '2024-09-16 02:59:47', 1, NULL),
(242, 1, 36, 1, 13, 9, 'Phuket Thai newtown', '2024-09-16 03:00:17', 1, NULL),
(243, 1, 22, 1, 13, 8, 'Super fast service and professional\nKi, Kam and Aim are the best helping me solve the problem since create the website, do the advertising also setup all payment program.  Thank you so much Localforyou. !!!\n', '2024-09-16 03:01:08', 1, NULL),
(244, 1, 23, 1, 13, 11, 'Auto-pilot campaign 3 coins for Aug', '2024-09-16 03:03:04', 1, NULL),
(245, 1, 23, 1, 13, 11, 'Auto-pilot campaign 3 coins for Aug', '2024-09-16 03:03:13', 1, NULL),
(246, 1, 23, 1, 13, 11, 'Auto-pilot campaign 3 coins for Aug', '2024-09-16 03:03:25', 1, NULL),
(247, 1, 12, 1, 13, 3, 'D Thai', '2024-09-16 03:04:37', 1, NULL),
(248, 1, 12, 1, 13, 5, 'New customer by phone call', '2024-09-16 03:05:20', 1, NULL),
(249, 1, 19, 1, 13, 11, 'Auto-pilot campaign 3 coins for Aug', '2024-09-16 03:06:02', 1, NULL),
(250, 1, 19, 1, 13, 11, 'Auto-pilot campaign 3 coins for Aug', '2024-09-16 03:06:11', 1, NULL),
(251, 1, 19, 1, 13, 11, 'Auto-pilot campaign 3 coins for Aug', '2024-09-16 03:06:18', 1, NULL),
(252, 1, 12, 2, 13, 11, 'Company game', '2024-09-26 03:13:31', 1, NULL),
(253, 1, 19, 2, 13, 1, 'Company game', '2024-09-26 03:13:41', 1, NULL),
(254, 1, 22, 2, 13, 1, 'Company game', '2024-09-26 03:13:49', 1, NULL),
(255, 1, 23, 2, 13, 1, 'Company game', '2024-09-26 03:14:00', 1, NULL),
(256, 1, 30, 2, 13, 1, 'Company game', '2024-09-26 03:14:07', 1, NULL),
(257, 1, 36, 2, 13, 1, 'Company game', '2024-09-26 03:14:15', 1, NULL),
(258, 1, 37, 2, 13, 1, 'Company game', '2024-09-26 03:14:28', 1, NULL),
(259, 1, 41, 2, 13, 1, 'Company game', '2024-09-26 03:14:39', 1, NULL),
(260, 1, 46, 2, 13, 1, 'Company game', '2024-09-26 03:14:51', 1, NULL),
(261, 1, 23, 1, 13, 11, 'Meet Client', '2024-09-26 03:36:05', 1, NULL),
(262, 1, 46, 1, 13, 11, 'Meet Client', '2024-09-26 03:36:32', 1, NULL),
(263, 1, 23, 1, 13, 11, 'P\' Jess testimonial', '2024-09-27 00:38:15', 1, NULL),
(264, 1, 46, 1, 13, 11, 'P\' Jess testimonial', '2024-09-27 00:38:22', 1, NULL),
(265, 1, 46, 2, 17, 11, 'Lead to the moon', '2024-11-05 04:40:06', 1, NULL),
(266, 1, 32, 1, 17, 11, 'Lead to the moon', '2024-11-05 04:40:23', 1, NULL),
(267, 1, 20, 7, 17, 5, 'Line', '2024-11-05 04:42:34', 1, NULL),
(268, 1, 61, 1, 17, 11, 'Lead to the moon', '2024-11-05 04:44:35', 1, NULL),
(269, 1, 26, 1, 31, 8, 'Google Review/Thaism', '2024-11-22 04:02:17', 1, NULL),
(270, 1, 16, 1, 42, 6, 'Referral from Blue Buddha Thai to Banana Leaf. ', '2024-11-22 04:02:26', 1, NULL),
(271, 1, 16, -1, 42, 1, 'Referral from Blue Buddha Thai to Banana Leaf. ของบีม กดผิด', '2024-11-22 04:03:14', 1, NULL),
(272, 1, 15, 1, 42, 6, 'Referral from Blue Buddha Thai to Banana Leaf.', '2024-11-22 04:03:36', 1, NULL),
(273, 1, 15, 1, 42, 11, 'Siri Thai Massage is a returning customer of mine, now changed name to Orakei Thai Massage. < Manager Coin', '2024-11-22 04:04:45', 1, NULL),
(274, 1, 26, 1, 31, 6, 'Referrals/Charoen Krung', '2024-11-22 04:04:53', 1, NULL),
(275, 1, 15, 1, 42, 11, 'Willaim Rejion > Manager Coin / Team activity', '2024-11-22 04:05:35', 1, NULL),
(276, 1, 26, 1, 31, 6, 'Referrals/Kin D Thai & Sushi', '2024-11-22 04:05:38', 1, NULL),
(277, 1, 16, 1, 42, 11, 'Salt Water Rejoin / Team Activity / Manager Coins', '2024-11-22 04:06:11', 1, NULL),
(278, 1, 15, 1, 42, 8, 'From Muang Thong Gloden City', '2024-11-22 04:06:35', 1, NULL),
(279, 1, 15, 1, 42, 8, 'From JALBN', '2024-11-22 04:06:56', 1, NULL),
(280, 1, 15, 1, 42, 9, 'Thai Beach Cafe', '2024-11-22 04:07:41', 1, NULL),
(281, 1, 39, 1, 31, 4, 'Upgrade - Blue Sky Thai Massage Waikiki Beach Walk - solo to bundle', '2024-11-22 04:07:43', 1, NULL),
(282, 1, 15, 1, 42, 9, 'Muang Thong Gloden City ', '2024-11-22 04:08:47', 1, NULL),
(283, 1, 39, 1, 31, 6, 'referrals - Beayou Clinic 2', '2024-11-22 04:10:51', 1, NULL),
(284, 1, 65, 1, 31, 4, 'Upgrade - Lux Thai Spa - solo to bundle', '2024-11-22 04:12:53', 1, NULL),
(285, 1, 65, 1, 31, 4, 'Upgrade - Siam Rice Thai & Tapas - solo to bundle', '2024-11-22 04:20:57', 1, NULL),
(286, 1, 65, 1, 31, 8, 'google review - Lilly Thai Holistic & Spa', '2024-11-22 04:22:38', 1, NULL),
(287, 1, 65, 1, 31, 6, 'referrals - What the pho - referred by Thai Me Up', '2024-11-22 04:28:06', 1, NULL),
(288, 1, 65, 1, 31, 11, 'Encourage customer to do catalog for their new restaurant - Siam Rice Thai and Tapas', '2024-11-22 04:34:06', 1, NULL),
(289, 1, 34, 1, 31, 11, 'team activity - Tong Thai Bistro', '2024-11-22 04:36:32', 1, NULL),
(290, 1, 34, 1, 31, 6, 'referrals - Dragon Nails - referred by Sphere Nails Shop', '2024-11-22 04:37:37', 1, NULL),
(291, 2, 32, 6, 1, 1, 'Employee of the quarter #3 2024', '2024-12-03 06:52:08', 1, NULL),
(292, 2, 65, 2, 1, 1, 'Top Referral Contributor 2024', '2024-12-03 06:54:43', 1, NULL),
(293, 2, 19, 2, 1, 1, 'The conference super stars 2024', '2024-12-03 06:56:26', 1, NULL),
(294, 2, 24, 2, 1, 1, 'The workplace comedian award', '2024-12-03 06:59:45', 1, NULL),
(295, 2, 50, 2, 1, 1, 'The Quiet Archiver award 2024', '2024-12-03 07:00:32', 1, NULL),
(296, 2, 14, 2, 1, 1, 'The behind the scenes hero 2024', '2024-12-03 07:01:15', 1, NULL),
(297, 2, 29, 5, 1, 1, 'Special conference CEO thanks ', '2024-12-03 07:01:43', 1, NULL),
(298, 2, 32, 1, 1, 1, 'TikTok Popular vote : Yoou & Nice', '2024-12-03 07:02:34', 1, NULL),
(299, 2, 50, 1, 1, 1, 'TikTok Popular vote : Yoou & Nice', '2024-12-03 07:02:46', 1, NULL),
(300, 2, 13, 1, 1, 1, 'TikTok Marketing Manager vote : Aom & Tan', '2024-12-03 07:03:21', 1, NULL),
(301, 2, 46, 1, 1, 1, 'TikTok Marketing Manager vote : Aom & Tan', '2024-12-03 07:03:30', 1, NULL),
(302, 2, 16, 2, 1, 1, 'TikTok CEO vote : Beam & Bee', '2024-12-03 07:04:05', 1, NULL),
(303, 2, 15, 2, 1, 1, 'TikTok CEO vote : Beam & Bee', '2024-12-03 07:04:18', 1, NULL),
(304, 1, 33, 2, 1, 2, 'Win Boom game on Conference 2024 : Peter , Nan', '2024-12-03 07:05:27', 1, NULL),
(305, 1, 31, 2, 1, 1, 'Win Boom game on Conference 2024 : Peter , Nan', '2024-12-03 07:05:42', 1, NULL),
(306, 2, 31, 10, 1, 2, 'Team activity winners at Conference 2024: Group 4 Love4U', '2024-12-03 07:08:11', 1, NULL),
(307, 2, 32, 10, 1, 2, 'Team activity winners at Conference 2024: Group 4 Love4U', '2024-12-03 07:08:31', 1, NULL),
(308, 2, 64, 10, 1, 2, 'Team activity winners at Conference 2024: Group 4 Love4U', '2024-12-03 07:08:51', 1, NULL),
(309, 2, 41, 10, 1, 2, 'Team activity winners at Conference 2024: Group 4 Love4U', '2024-12-03 07:09:28', 1, '2024-12-03 07:11:40'),
(310, 2, 46, 10, 1, 2, 'Team activity winners at Conference 2024: Group 4 Love4U', '2024-12-03 07:12:11', 1, NULL),
(311, 2, 19, 10, 1, 2, 'Team activity winners at Conference 2024: Group 4 Love4U', '2024-12-03 07:12:30', 1, NULL),
(312, 2, 35, 10, 1, 2, 'Team activity winners at Conference 2024: Group 4 Love4U', '2024-12-03 07:12:55', 1, NULL),
(313, 2, 62, 10, 1, 2, 'Team activity winners at Conference 2024: Group 4 Love4U', '2024-12-03 07:13:23', 1, NULL),
(314, 2, 27, 10, 1, 2, 'Team activity winners at Conference 2024: Group 4 Love4U', '2024-12-03 07:13:47', 1, NULL),
(315, 2, 46, 110, 46, 10, 'CEO to L4U', '2024-12-03 09:20:06', 1, NULL),
(316, 2, 24, 30, 24, 10, 'CEO to L4U', '2024-12-03 16:28:35', 1, NULL),
(317, 2, 41, 140, 41, 10, 'CEO to L4U', '2024-12-03 23:52:08', 1, NULL),
(318, 2, 64, 100, 64, 10, 'CEO to L4U', '2024-12-04 04:14:56', 1, NULL);

DROP TABLE IF EXISTS `CoinType`;
CREATE TABLE `CoinType` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `val` mediumint(8) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `CoinType` (`id`, `name`, `val`) VALUES
(1, 'L4U', 50),
(2, 'CEO', 500);

DROP TABLE IF EXISTS `Countries`;
CREATE TABLE `Countries` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `code` varchar(5) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `Countries` (`id`, `code`, `name`, `status`) VALUES
(1, 'AU', 'Australia', 1),
(2, 'NZ', 'New Zealand', 1),
(3, 'US', 'United States', 1),
(4, 'TH', 'Thailand', 0),
(5, 'UK', 'United Kingdom', 1),
(6, 'CA', 'Canada', 1);

DROP TABLE IF EXISTS `CustomerType`;
CREATE TABLE `CustomerType` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `CustomerType` (`id`, `name`, `value`, `status`) VALUES
(1, '--None--', '', 1),
(2, 'Thailand Restaurant', 'Thailand Restaurant', 1),
(3, 'Thai Restaurants & Takeaways', 'Thai Restaurants &amp; Takeaways', 1),
(4, 'Thai Massage', 'Thai Massage', 1),
(5, 'Restaurants & Takeaways', 'Restaurants &amp; Takeaways', 1);

DROP TABLE IF EXISTS `Employees`;
CREATE TABLE `Employees` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `nickName` varchar(255) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `pic` varchar(100) NOT NULL DEFAULT 'nopic.png',
  `teamID` tinyint(3) UNSIGNED NOT NULL DEFAULT 7,
  `L4U` float UNSIGNED NOT NULL DEFAULT 0,
  `CEO` float UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `activeDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `Employees` (`id`, `nickName`, `fullName`, `pic`, `teamID`, `L4U`, `CEO`, `status`, `activeDate`) VALUES
(1, 'Aim', 'Julaluk Pinit', '01-Aim.png', 1, 3, 0, 1, '2022-01-01'),
(2, 'Aom', 'Kunrisa Boonchutinan', '02-Aom.png', 1, 25, 0, 1, '2022-01-01'),
(3, 'Beam', 'Preeyaphorn Joyem', '04-Beam.png', 2, 0, 0, 1, '2022-01-01'),
(4, 'Bee', 'Kevalee Jindatajak', '05-Bee.png', 1, 0, 0, 1, '2022-01-01'),
(5, 'Boom', 'Piyakorn Joyem', '06-Boom.png', 3, 3, 0, 1, '2022-01-01'),
(6, 'Dear', 'Lapasrada Chaiyaporn', '07-Dear.png', 3, 0, 0, 0, '2022-01-01'),
(7, 'Eva', 'Anongnat Meepim', '08-Eva.png', 1, 0, 0, 1, '2022-01-01'),
(8, 'Faye', 'Thitiporn Pongwittayanusorn', '09-Faya.png', 3, 0, 0, 1, '2022-01-01'),
(9, 'Fern', 'Paweena Ngamapinyakul', '10-Fern.png', 3, 2, 0, 1, '2022-01-01'),
(10, 'Gam', 'Anantida Chekchuenkul', '11-Gam.png', 1, 0, 0, 1, '2022-01-01'),
(11, 'Gao', 'Jutapa Tuncharoen', '12-Gao.png', 1, 0, 0, 1, '2022-01-01'),
(12, 'Honey', 'Tummaput', '13-Honey.png', 3, 0, 0, 1, '2022-01-01'),
(13, 'John', 'John Lagoudakis', '14-John.png', 2, 2, 0, 1, '2022-01-01'),
(14, 'Mild', 'Watcharaporn Charoenrittikai', '17-Mild.png', 2, 0, 0, 1, '2022-01-01'),
(15, 'Mui', 'Warathip', '18-Mui.png', 4, 0, 0, 1, '2022-01-01'),
(16, 'Nam', 'Vichaitanapat', '19-Nam.png', 1, 1, 0, 1, '2022-01-01'),
(17, 'Nan', 'Julkraianisong', '20-Nan.png', 8, 0, 0, 1, '2022-01-01'),
(18, 'Neung', 'Sorasak Thanomsap', '22-Neung.png', 5, 12, 0, 1, '2022-01-01'),
(19, 'Nice', 'Kingkarn Yuenpairoj', '23-Nice.png', 2, 0, 0, 1, '2022-01-01'),
(20, 'Peter', 'Pheeraya Tonguamyai', '30-Peter.png', 2, 0, 0, 1, '2022-01-01'),
(21, 'Piano', 'Wattanapannasorn', '32-Piano.png', 2, 0, 0, 1, '2022-01-01'),
(22, 'Pluem', 'Pluem Pluemkamol', '33-Pluem.png', 3, 0, 0, 1, '2022-01-01'),
(23, 'Pookie', 'Nantaporn Pimsuwan', '34-Pookie.png', 1, 0, 0, 1, '2022-01-01'),
(24, 'Porsche', 'Panita Phueksapanachat', '35-Porsche.png', 1, 0, 0, 1, '2022-01-01'),
(25, 'Pruek', 'Pruek Patipatsinlapakit', '36-Pruek.png', 3, 0, 0, 1, '2023-10-25'),
(26, 'Pun', 'Surattana Haoboon', '37-Pun.png', 2, 0, 0, 1, '2022-01-01'),
(27, 'Sai', 'Jutatip Kankaew', '40-Sai.png', 1, 0, 0, 1, '2022-01-01'),
(28, 'San', 'Laongnual', '41-San.png', 2, 0, 0, 1, '2022-01-01'),
(29, 'Sol', 'Phatsara Khachornpob', '42-Sol.png', 2, 0, 0, 1, '2022-01-01'),
(30, 'Steve', 'Steven Waterson', '44-Steve.png', 6, 0, 0, 1, '2022-01-01'),
(31, 'Tan', 'Suwattana Panchapornudomlap', '45-Tan.png', 1, 0, 0, 1, '2022-01-01'),
(32, 'Toffee', 'Mananya Phamonphon', '46-Toffee.png', 3, 0, 0, 1, '2022-01-01'),
(33, 'Yok', 'Nattiya Joyem', '48-Yok.png', 4, 0, 0, 1, '2022-01-01'),
(34, 'Yoou', 'Pattaranun Lim-olansuksakul', '49-Yoou.png', 5, 0, 0, 1, '2023-10-23'),
(35, 'Cindy', 'Sirawongjaroen', 'nopic.png', 1, 0, 0, 0, '2022-01-01'),
(36, 'Jane', 'Suksri', 'nopic.png', 1, 0, 0, 0, '2022-01-01'),
(37, 'Mai', 'Boonsita', 'nopic.png', 1, 0, 0, 0, '2022-01-01'),
(38, 'Manow', 'Sermcharoenkit', 'nopic.png', 2, 0, 0, 0, '2022-01-01'),
(39, 'Nicky', 'Sutthida', 'nopic.png', 1, 0, 0, 0, '2022-01-01'),
(40, 'Noom', 'Suwansri', 'nopic.png', 1, 0, 0, 0, '2022-01-01'),
(41, 'Stef', 'Steven Fazakerley', '43-Stef.png', 6, 0, 0, 1, '2022-01-01'),
(42, 'Vance', 'Vance De Guzman', '47-Vance.png', 5, 0, 0, 1, '2022-01-01'),
(43, 'Ken', 'Ken Vic', '16-Ken.png', 5, 0, 0, 1, '2022-01-01'),
(44, 'Rhigny', 'Rhig Macareal', '38-Rhig.png', 5, 0, 0, 1, '2022-01-01'),
(45, 'Amy', 'Amy', 'nopic.png', 4, 0, 0, 0, '2022-01-01'),
(46, 'Liew', 'Liew', 'nopic.png', 7, 0, 0, 0, '2022-01-01'),
(47, 'Bas', 'Peeraphat Malimongkhon', '03-Bas.png', 5, 0, 0, 1, '2023-11-20'),
(49, 'Kamkuk', 'Patthanan Kositpipat', '15-Kamkuk.png', 8, 0, 0, 1, '2022-01-01');

DROP TABLE IF EXISTS `ExpenseDetail`;
CREATE TABLE `ExpenseDetail` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `typeID` tinyint(3) UNSIGNED NOT NULL,
  `value` float UNSIGNED NOT NULL,
  `month` enum('01','02','03','04','05','06','07','08','09','10','11','12') NOT NULL,
  `year` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `ExpenseDetail` (`id`, `typeID`, `value`, `month`, `year`) VALUES
(1, 1, 1200, '09', '2023'),
(2, 1, 1200, '10', '2023'),
(4, 2, 180.11, '09', '2023'),
(5, 2, 167.38, '10', '2023'),
(6, 2, 203.12, '11', '2023'),
(7, 3, 80, '08', '2023'),
(8, 3, 80, '09', '2023'),
(9, 3, 80, '10', '2023'),
(10, 4, 200.06, '09', '2023'),
(11, 4, 225.67, '10', '2023'),
(13, 5, 15.32, '08', '2023'),
(14, 5, 18.43, '09', '2023'),
(15, 5, 14.11, '10', '2023'),
(16, 6, 125.25, '09', '2023'),
(17, 6, 140.09, '10', '2023'),
(19, 7, 4800.97, '08', '2023'),
(20, 7, 4900.52, '09', '2023'),
(21, 7, 4900, '10', '2023'),
(22, 8, 250, '09', '2023'),
(23, 8, 250, '10', '2023'),
(24, 8, 250, '11', '2023'),
(25, 9, 550.67, '08', '2023'),
(26, 9, 320, '09', '2023'),
(27, 9, 178, '10', '2023'),
(31, 1, 99, '11', '2023'),
(32, 7, 5454, '11', '2023'),
(33, 10, 50000, '09', '2023'),
(34, 10, 50000, '10', '2023'),
(36, 10, 50000, '12', '2023'),
(37, 11, 58.53, '09', '2023'),
(38, 11, 41.35, '10', '2023'),
(39, 11, 99.8, '11', '2023'),
(40, 11, 24.32, '12', '2023'),
(41, 12, 258.12, '09', '2023'),
(42, 12, 329.05, '10', '2023'),
(43, 12, 278.43, '11', '2023'),
(44, 12, 299.25, '12', '2023'),
(45, 13, 2435.98, '09', '2023'),
(46, 13, 3532.11, '10', '2023'),
(47, 13, 3852.78, '11', '2023'),
(48, 13, 2032.01, '12', '2023'),
(49, 14, 2532.4, '09', '2023'),
(50, 14, 4853.22, '10', '2023'),
(51, 14, 345.02, '11', '2023'),
(52, 14, 70.65, '12', '2023'),
(53, 10, 5555, '11', '2023');

DROP TABLE IF EXISTS `ExpenseType`;
CREATE TABLE `ExpenseType` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `typeName` varchar(255) NOT NULL,
  `typeSection` enum('bkkOffice','THOperation','CEOLiving') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `ExpenseType` (`id`, `typeName`, `typeSection`) VALUES
(1, 'Office rent', 'bkkOffice'),
(2, 'Electricity bill', 'bkkOffice'),
(3, 'Internet fees', 'bkkOffice'),
(4, 'Parking fee', 'bkkOffice'),
(5, 'Drinking Water', 'bkkOffice'),
(6, 'Snacks', 'bkkOffice'),
(7, 'Staff BKK', 'THOperation'),
(8, 'Accounting', 'THOperation'),
(9, 'Documentation', 'THOperation'),
(10, 'House Rental', 'CEOLiving'),
(11, 'Documentation', 'CEOLiving'),
(12, 'Water', 'CEOLiving'),
(13, 'Electricity', 'CEOLiving'),
(14, 'Others', 'CEOLiving');

DROP TABLE IF EXISTS `exp_project`;
CREATE TABLE `exp_project` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `owner_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `create_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_on` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `exp_project` (`id`, `name`, `status`, `owner_id`, `create_on`, `update_on`) VALUES
(1, 'test project bas\'s', 1, 14, '2024-05-01 01:25:14', NULL);

DROP TABLE IF EXISTS `IHDDetail`;
CREATE TABLE `IHDDetail` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `typeID` tinyint(3) UNSIGNED NOT NULL,
  `month` enum('01','02','03','04','05','06','07','08','09','10','11','12') NOT NULL,
  `year` year(4) NOT NULL,
  `value` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `IHDDetail` (`id`, `typeID`, `month`, `year`, `value`) VALUES
(1, 1, '10', '2023', 207),
(2, 1, '09', '2023', 413),
(3, 1, '08', '2023', 145),
(4, 2, '10', '2023', 202),
(5, 2, '09', '2023', 539),
(6, 2, '08', '2023', 109),
(7, 3, '10', '2023', 202),
(8, 3, '09', '2023', 204),
(9, 3, '08', '2023', 414),
(11, 2, '11', '2023', 617),
(13, 3, '11', '2023', 617),
(21, 1, '11', '2023', 222),
(22, 1, '01', '2024', 1222);

DROP TABLE IF EXISTS `IHDType`;
CREATE TABLE `IHDType` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `IHDType` (`id`, `name`, `status`) VALUES
(1, 'IHD 20c AU', 1),
(2, 'IHD $1 Marketplace AU', 1),
(3, 'IHD 25c USA', 1),
(4, 'IHD $1 Marketplace USA', 1);

DROP TABLE IF EXISTS `passwordmanager`;
CREATE TABLE `passwordmanager` (
  `id` tinyint(4) NOT NULL,
  `pwName` varchar(255) NOT NULL,
  `pwLink` varchar(255) NOT NULL,
  `pwUser` varchar(255) NOT NULL,
  `pwPass` text NOT NULL,
  `pwLevel` tinyint(1) NOT NULL,
  `pwNote` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `passwordmanager` (`id`, `pwName`, `pwLink`, `pwUser`, `pwPass`, `pwLevel`, `pwNote`) VALUES
(4, 'Dreamscape', 'https://reseller.ds.network/', 'admin@localforyou.com', 'admin2022', 4, ''),
(5, 'Gloria Foods (All Shopping cart)ADA', '', 'admin@localforyou.com', 'L4U@2017:)', 3, ''),
(6, 'Facebook: Aaliyah', 'https://facebook.com/', 'localforyou1@gmail.com', 'Localforyou2023!', 3, 'ติด 2FA ผ่านสมาร์ทโฟน'),
(7, 'Email Admin (Official)', 'https://gmail.com/', 'admin@localforyou.com', 'L4U@2017:)', 4, ''),
(8, 'CRM admin', '', 'admin@localforyou.com', 'L4U@2017:)', 4, ''),
(9, 'Restaurant order taking demo', '', 'demoeats@localforyou.com', 'L4U@2017:)', 4, ''),
(10, 'Shopping Cart', 'https://www.localforyoucart.com/', 'demoeats@localforyou.com', 'L4U@2017:)', 4, ''),
(12, 'Demoeat Thai (Shopping cart)', 'https://www.localforyoucart.com/', 'demoeatsthai@localforyou.com', 'L4U@2017:)', 4, ''),
(13, 'Email Sales', 'https://gmail.com/', 'sales@localforyou.com', 'L4U@2017:)', 3, ''),
(14, 'Respond io Sale', 'https://respond.io/', 'sales@localforyou.com', 'L4u@2017:)', 4, ''),
(15, 'Admin payment update', '', 'admin@localforyou.com', 'Localforyou2021', 3, 'ไม่รู้เข้าที่ไหน'),
(16, 'All Massage Wordpress', '', 'admin@localforyou.com', 'L4U=New@min', 4, 'บางอันยังเป็นรหัสเก่า: Localforyou2023!'),
(17, 'Youcanbookme Sales', 'https://youcanbook.me/', 'sales@localforyou.com', 'L4u@2017:)!!', 4, ''),
(18, 'Docusign', 'https://www.docusign.com/', 'sales@localforyou.com', 'Localforyou2022', 4, ''),
(22, 'Email Admin (old)', 'https://gmail.com/', 'localforyou1@gmail.com', 'L4U2021!', 4, '');

DROP TABLE IF EXISTS `Products`;
CREATE TABLE `Products` (
  `pID` tinyint(3) UNSIGNED NOT NULL,
  `pName` varchar(255) NOT NULL,
  `pShortName` varchar(255) NOT NULL,
  `pTypeShop` enum('Restaurant','Massage') NOT NULL DEFAULT 'Restaurant',
  `pStatus` tinyint(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `Products` (`pID`, `pName`, `pShortName`, `pTypeShop`, `pStatus`) VALUES
(1, 'Pro Online Ordering System', 'Pro Online', 'Restaurant', 1),
(2, 'Social Media Marketing Bundle', 'Social Bundle', 'Restaurant', 1),
(3, 'Direct Marketing Bundle', 'Direct Bundle', 'Restaurant', 1),
(4, 'Mega Marketing Bundle', 'Mega Bundle', 'Restaurant', 1),
(5, 'Social Media Marketing Solo', 'Social Solo', 'Restaurant', 1),
(6, 'Direct Marketing Solo', 'Direct Solo', 'Restaurant', 1),
(7, 'Mega Marketing Solo', 'Mega Solo', 'Restaurant', 1),
(8, 'Autopilot', 'Autopilot', 'Restaurant', 1),
(9, 'Localforyou Booking System', 'Booking System', 'Massage', 1),
(10, 'Social Media Marketing Bundle', 'Social Bundle', 'Massage', 1),
(11, 'Direct Marketing Bundle', 'Direct Bundle', 'Massage', 1),
(12, 'Mega Marketing Bundle', 'Mega Bundle', 'Massage', 1),
(13, 'Social Media Marketing Solo', 'Social Solo', 'Massage', 1),
(14, 'Direct Marketing Solo', 'Direct Solo', 'Massage', 1),
(15, 'Mega Marketing Solo', 'Mega Solo', 'Massage', 1),
(16, 'Autopilot', 'Autopilot', 'Massage', 1);

DROP TABLE IF EXISTS `Religion`;
CREATE TABLE `Religion` (
  `rID` tinyint(3) UNSIGNED NOT NULL,
  `rName` varchar(100) NOT NULL,
  `rThane` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `Religion` (`rID`, `rName`, `rThane`) VALUES
(1, 'None', 'ไม่ระบุ'),
(2, 'Irreligion', 'ไม่นับถือศาสนา'),
(3, 'Buddhism', 'พุทธ'),
(4, 'Christianity', 'คริสต์'),
(5, 'Islam', 'อิสลาม'),
(6, 'Hinduism', 'พราหมณ์-ฮินดู'),
(7, 'Sikhism', 'ซิกข์'),
(8, 'Judaism', 'ยิว'),
(9, 'Jainism', 'เชน'),
(10, 'Zoroastrianism', 'โซโรอัสเตอร์'),
(11, 'Shintoism', 'ชินโต'),
(12, 'Confucius', 'ขงจื๊อ'),
(13, 'Taoism', 'เต๋า');

DROP TABLE IF EXISTS `RevenueDetail`;
CREATE TABLE `RevenueDetail` (
  `rID` int(10) UNSIGNED NOT NULL,
  `pID` tinyint(3) UNSIGNED NOT NULL COMMENT 'product id',
  `rCountryID` tinyint(3) UNSIGNED NOT NULL,
  `rMonth` enum('01','02','03','04','05','06','07','08','09','10','11','12') NOT NULL,
  `rYear` year(4) NOT NULL,
  `rValue` float NOT NULL,
  `rStatus` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `rCreateOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `rCreateBy` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `RevenueDetail` (`rID`, `pID`, `rCountryID`, `rMonth`, `rYear`, `rValue`, `rStatus`, `rCreateOn`, `rCreateBy`) VALUES
(1, 1, 1, '03', '2024', 2000, 1, '2024-03-17 09:44:57', 1),
(2, 2, 1, '03', '2024', 1600, 1, '2024-03-17 09:45:09', 1),
(3, 3, 1, '03', '2024', 450, 1, '2024-03-17 09:45:23', 1),
(4, 4, 1, '03', '2024', 6544, 1, '2024-03-17 09:46:56', 1),
(5, 5, 1, '03', '2024', 3289, 1, '2024-03-17 09:47:08', 1),
(6, 6, 1, '03', '2024', 233.44, 1, '2024-03-17 09:47:21', 1),
(7, 7, 1, '03', '2024', 3910, 1, '2024-03-17 09:48:01', 1),
(8, 8, 1, '03', '2024', 340, 1, '2024-03-17 09:48:23', 1);

DROP TABLE IF EXISTS `rewardcategories`;
CREATE TABLE `rewardcategories` (
  `rcID` tinyint(3) UNSIGNED NOT NULL,
  `rtID` tinyint(3) UNSIGNED NOT NULL,
  `rcTitle` varchar(150) NOT NULL,
  `rcSpend` float UNSIGNED NOT NULL,
  `rcReward` varchar(300) NOT NULL,
  `rcStatus` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `rcPic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `rewardcategories` (`rcID`, `rtID`, `rcTitle`, `rcSpend`, `rcReward`, `rcStatus`, `rcPic`) VALUES
(1, 1, 'Cash out', 10, '500 Baht', 1, '500cash.png'),
(2, 1, 'Cash out', 20, '1,000 Baht', 1, '1000cash.png'),
(3, 1, 'Cash out', 30, '1,500 Baht', 1, '1500cash.png'),
(4, 1, 'Cash out', 40, '2,000 Baht', 1, '2000cash.png'),
(5, 1, 'Cash out', 50, '2,500 Baht', 1, '2500cash.png'),
(6, 2, 'Extra vacation days', 20, '1 Day', 1, '1dayoff.png'),
(7, 5, 'Disney plus', 35, 'Disney + Hotstar 1 year', 1, 'disneyplus.png'),
(8, 5, 'Bed Movie Night', 40, '2 Premium Movie Tickets', 1, '2movieticket.png'),
(9, 3, 'Date night', 45, '1 night accommodation (min. 3 start) and dinner for 2 people', 1, '1datenight.png'),
(10, 4, 'AirPods', 115, 'AirPods III', 1, 'airpodsIII.png'),
(11, 3, 'Vacation Package', 125, '3 Nights in Phuket (Accommodation only)', 1, '3nightsPhuket.png'),
(12, 4, 'Apple Watch', 225, 'Apple Watch Series 9', 1, 'applewatch9.png'),
(13, 4, 'iPad', 350, 'IPad Air', 1, 'ipadair.png'),
(14, 4, 'iPhone', 455, 'iPhone 15 (128GB)', 1, 'iphone15.png');

DROP TABLE IF EXISTS `rewardstype`;
CREATE TABLE `rewardstype` (
  `rtID` tinyint(3) UNSIGNED NOT NULL,
  `rtName` varchar(100) NOT NULL,
  `rtStatus` tinyint(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `rewardstype` (`rtID`, `rtName`, `rtStatus`) VALUES
(1, 'Money', 1),
(2, 'Holiday', 1),
(3, 'Travel', 1),
(4, 'Gadgets', 1),
(5, 'Entertainment', 1);

DROP TABLE IF EXISTS `SpendLogs`;
CREATE TABLE `SpendLogs` (
  `id` int(10) UNSIGNED NOT NULL,
  `coinType` tinyint(4) DEFAULT NULL,
  `ownerID` tinyint(3) UNSIGNED DEFAULT NULL,
  `amount` float NOT NULL DEFAULT 0,
  `spendType` tinyint(4) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `spendBy` tinyint(4) DEFAULT NULL,
  `spendOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `SpendLogs` (`id`, `coinType`, `ownerID`, `amount`, `spendType`, `reason`, `spendBy`, `spendOn`, `status`) VALUES
(1, 1, 36, 20, 5, 'Redeem for day off', 36, '2024-06-07 00:57:38', 1),
(2, 2, 28, -20, 3, 'CEO to L4U', 28, '2024-07-29 05:43:52', 1),
(3, 1, 28, -20, 4, 'Redeem to cash', 28, '2024-07-29 05:44:08', 1),
(4, 1, 35, -40, 4, 'Redeem to cash', 35, '2024-08-16 04:46:32', 1),
(5, 2, 35, -40, 3, 'CEO to L4U', 35, '2024-08-16 04:47:43', 1),
(6, 1, 35, -40, 4, 'Redeem to cash', 35, '2024-08-16 04:47:51', 1),
(7, 1, 21, -50, 4, 'Redeem to cash', 21, '2024-08-16 14:37:30', 1),
(8, 1, 15, -20, 4, 'Redeem to cash', 15, '2024-08-22 02:32:19', 1),
(9, 2, 34, -20, 3, 'CEO to L4U', 34, '2024-09-03 23:03:05', 1),
(10, 2, 46, -110, 3, 'CEO to L4U', 46, '2024-12-03 09:20:06', 1),
(11, 2, 24, -30, 3, 'CEO to L4U', 24, '2024-12-03 16:28:35', 1),
(12, 2, 41, -140, 3, 'CEO to L4U', 41, '2024-12-03 23:52:08', 1),
(13, 2, 64, -100, 3, 'CEO to L4U', 64, '2024-12-04 04:14:56', 1);

DROP TABLE IF EXISTS `SpendType`;
CREATE TABLE `SpendType` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `SpendType` (`id`, `name`, `status`) VALUES
(1, 'Redeem Gift Card', 1),
(2, 'Transfer Coin', 1),
(3, 'Convert Coin', 1),
(4, 'Exchange for cash', 1),
(5, 'Day off', 1);

DROP TABLE IF EXISTS `staffs`;
CREATE TABLE `staffs` (
  `sID` tinyint(3) UNSIGNED NOT NULL,
  `sEmpID` varchar(6) DEFAULT NULL COMMENT 'รหัสพนักงาน',
  `sName` varchar(255) NOT NULL COMMENT 'full name',
  `sNickName` varchar(50) DEFAULT NULL COMMENT 'nickname',
  `sTName` varchar(255) DEFAULT NULL COMMENT 'ชื่อไทย',
  `sEmail` text NOT NULL,
  `sMobile` text NOT NULL,
  `sPassword` text NOT NULL,
  `sStatus` tinyint(1) NOT NULL DEFAULT 1,
  `sPic` varchar(100) NOT NULL DEFAULT 'no_pic.png',
  `sDOB` date DEFAULT NULL COMMENT 'วันเกิด',
  `rID` tinyint(3) UNSIGNED NOT NULL DEFAULT 1 COMMENT 'Religion ID',
  `sAddress` text NOT NULL COMMENT 'Currently Address',
  `sL4U` float NOT NULL DEFAULT 0,
  `sCEO` float NOT NULL DEFAULT 0,
  `teamID` tinyint(3) UNSIGNED DEFAULT 7,
  `sLevel` tinyint(1) UNSIGNED NOT NULL DEFAULT 4,
  `sLogin` datetime DEFAULT NULL,
  `sToken` varchar(32) DEFAULT NULL,
  `sActiveDate` date DEFAULT NULL COMMENT 'Join Date',
  `sCreateBy` tinyint(3) UNSIGNED DEFAULT NULL,
  `sCreateAt` datetime NOT NULL DEFAULT current_timestamp(),
  `sUpdateAt` datetime DEFAULT NULL,
  `sUpdateBy` tinyint(4) UNSIGNED DEFAULT NULL,
  `sDeleteAt` datetime DEFAULT NULL,
  `sDeleteBy` tinyint(3) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staffs` (`sID`, `sEmpID`, `sName`, `sNickName`, `sTName`, `sEmail`, `sMobile`, `sPassword`, `sStatus`, `sPic`, `sDOB`, `rID`, `sAddress`, `sL4U`, `sCEO`, `teamID`, `sLevel`, `sLogin`, `sToken`, `sActiveDate`, `sCreateBy`, `sCreateAt`, `sUpdateAt`, `sUpdateBy`, `sDeleteAt`, `sDeleteBy`) VALUES
(1, 'LOC033', 'Sorasak Thanomsap', 'Neung', 'สรศักดิ์ ถนอมทรัพย์', 'neung@localforyou.com', '0895117447', '7eddda3e99cd23ed5d8deb5dc9cce0ec', 1, '22-Neung.png', '1983-11-01', 5, '287/245 ซอย 2 หมู่บ้านพฤกษา78 ถนนเลียบคลองลำกอไผ่ แขวงลำปลาทิว เขตลาดกระบัง กทม. 10520', 1, 0, 5, 1, '2024-12-04 11:33:47', '561de9c0191da7a01e548b088b9ccfe2', '2019-01-07', 0, '2023-02-10 14:54:33', '2023-10-26 15:04:05', 1, NULL, NULL),
(12, 'LOC053', 'Julaluk Pinit', 'Aim', 'จุฬาลักษณ์ พินิจ', 'aim@localforyou.com', '0929855589', 'e30d60a4848903ed23c42a8d45eccdba', 1, '01-Aim.png', '1988-10-20', 3, '9/5 ซ.ถ้ำตาปาน ต.ท้ายช้าง อ.เมืองพังงา จ.พังงา 82000', 9, 0, 1, 4, '2024-09-29 02:03:37', '1795d1ba1ece0cf01f86553fd4e500d7', '2023-08-14', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(13, 'LOC009', 'Kunrisa Boonchutinan', 'Aom', 'กุลริศา บุญชุตินันท์', 'aom@localforyou.com', '0959503113', 'e30d60a4848903ed23c42a8d45eccdba', 1, '02-Aom.png', '1998-07-09', 1, '', 1, 1, 1, 3, '2024-09-27 08:37:40', 'b5a2f2263c196369ce0be75990b095bc', '2021-07-05', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(14, 'LOC060', 'Peeraphat Malimongkhon', 'Bas', 'พีรภัทร มะลิมงคล', 'bas@localforyou.com', '0930396203', 'e188d410553eca95f96cd8b3f9f35bad', 1, '03-Bas.png', '1999-08-11', 4, 'อพาร์ทเม้นท์ นัชษา เพลส 2 93/1 ซอย พัฒนาการ 20 แยก 4 แขวง สวนหลวง แขวงสวนหลวง กรุงเทพมหานคร 10250', 6, 4, 5, 4, '2024-12-03 15:33:41', 'b04a3add7a0ca36d0391a6e3273cbd3b', '2023-11-20', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(15, 'LOC037', 'Preeyaphorn Joyem', 'Beam', 'ปรียาภรณ์ จ้อยเอม', 'beam@localforyou.com', '0990035565', 'e30d60a4848903ed23c42a8d45eccdba', 1, '04-Beam.png', '1998-12-16', 4, '226/437 18A อาคารริเวียร่า4 หมู่3 ถ.บอนด์สตรีท ต.บางพูด อ.ปากเกร็ด จ.นนทบุรี 11120', 34, 2, 2, 4, '2024-09-19 16:07:59', '7b47a2fa0179d44280f876a8df218447', '2022-12-19', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(16, 'LOC012', 'Kevalee Jindatajak', 'Bee', 'เกวลี จินดาทจักร์', 'bee@localforyou.com', '0966679945', 'e30d60a4848903ed23c42a8d45eccdba', 1, '05-Bee.png', '1998-01-22', 1, '', 5, 4, 2, 4, '2024-12-03 17:12:06', '782aaa021fe002b6403f4533c022a8b4', '2021-08-23', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(17, 'LOC018', 'Piyakorn Joyem', 'Boom', 'ปิยะกร จ้อยเอม', 'boom@localforyou.com', '0838388056', 'e30d60a4848903ed23c42a8d45eccdba', 1, '06-Boom.png', '1996-11-14', 4, '', 1, 3, 3, 3, '2024-11-05 12:37:00', 'e68e7f3e030f98c41b2ef7b56c4441ee', '2022-01-04', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(18, 'LOC056', 'Lapasrada Chaiyaporn', 'Dear', 'ลภัสรดา ไชยพร', 'dear@localforyou.com', '0843171291', 'e30d60a4848903ed23c42a8d45eccdba', 0, '07-Dear.png', NULL, 3, '8/524 หมู่บ้านลัดดาวิลล์5 ถนนบางกรวย-ไทรน้อย ตำบลบางบัวทอง อำเภอบางบัวทอง จังหวัดนนทบุรี 11110', 0, 0, 3, 4, NULL, NULL, '2020-01-01', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(19, 'LOC013', 'Anongnat Meepim', 'Eva', 'อนงค์นาถ มีพิมพ์', 'eva@localforyou.com', '0637960686', 'e30d60a4848903ed23c42a8d45eccdba', 1, '08-Eva.png', '1997-09-28', 1, '', 11, 12, 1, 4, '2024-08-10 03:28:28', 'b360345f81246d7f31501a160ac3b9ea', '2021-09-20', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(20, 'LOC049', 'Thitiporn Pongwittayanusorn', 'Faye', 'ฐิติพร พงษ์วิทยานุสรณ์', 'faye@localforyou.com', '0803421909', 'e30d60a4848903ed23c42a8d45eccdba', 1, '09-Faya.png', '1999-07-28', 3, 'แฮปปี้คอนโด 223/16 ซอยช่างอากาศอุทิศ แขวงดอนเมือง เขตดอนเมือง กรุงเทพฯ 10210', 36, 0, 3, 4, '2024-12-04 00:15:23', 'c3ce62fdf88b4d07f0d7be64512aaedb', '2023-05-06', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(21, 'LOC043', 'Paweena Ngamapinyakul', 'Fern', 'ปวีณา งามอภิญญากุล', 'paweena@localforyou.com', '0616273468', 'e30d60a4848903ed23c42a8d45eccdba', 1, '10-Fern.png', '1999-02-23', 4, '53/136 มิตรประชา21 ต.บ้านใหม่ อ.ปากเกร็ด จ.นนทบุรี 11120', 11, 1, 3, 4, '2024-08-16 22:36:31', '17e65fe47a40078a34e34f94934af4b1', '2023-02-20', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(22, 'LOC052', 'Anantida Chekchuenkul', 'Gam', 'อนัญธิดา เช็กชื่นกุล', 'gam@localforyou.com', '0842984483', 'e30d60a4848903ed23c42a8d45eccdba', 1, '11-Gam.png', '1992-02-09', 3, '1482/175 นิติบุคคลอาคารชุด ลุมพินีเพลส รัชโยธิน แขวง จันทรเกษม เขต จตุจักร กรุงเทพมหานคร 10900', 4, 0, 1, 4, '2024-01-03 07:04:19', '1d396cef1c0fec3a5f89db7d6b449af0', '2023-08-01', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(23, 'LOC050', 'Jutapa Tuncharoen', 'Gao', 'จุฑาภา ตันเจริญ', 'gao@localforyou.com', '0956356650', 'e30d60a4848903ed23c42a8d45eccdba', 0, '12-Gao.png', '1993-01-09', 3, '102 หมู่4 ต.บ่อสุพรรณ อ.สองพี่น้อง จ.สุพรรณบุรี 72190', 18, 0, 1, 4, '2024-06-08 18:16:11', '2035438b9bb104dbb70975d7dc0411d1', '2023-06-07', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(24, 'LOC007', 'Nitipun Tummaput', 'Honey', 'นิธิพันธ์ ธรรมพุฒ', 'honey@localforyou.com', '0858480729', 'e30d60a4848903ed23c42a8d45eccdba', 1, '13-Honey.png', '1992-06-06', 1, '', 44, 0, 3, 4, '2024-12-04 00:26:49', 'd90e17a4b9c4de53a3f98fdbcdc18686', '2021-04-01', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(25, NULL, 'John Lagoudakis', 'John', 'จอนห์ ลากูดากิส', 'johnl@localforyou.com', '-', 'e30d60a4848903ed23c42a8d45eccdba', 1, '14-John.png', NULL, 1, '', 1, 0, 2, 4, '2024-01-03 07:19:57', '2d7cab46c440ec33b4baad563ba93d7c', '2020-01-01', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(26, 'LOC059', 'Patthanan Kositpipat', 'Kamkuk', 'พัทธนันท์ โฆษิตพิพัฒน์', 'kamkuk@localforyou.com', '0896228035', 'e30d60a4848903ed23c42a8d45eccdba', 1, '15-Kamkuk.png', '1992-05-25', 3, '199/157 Notting hill สุขุมวิท 105 ลาซาล แขวงบางนาใต้ เขตบางนา กทม. 10260', 22, 0, 8, 4, '2024-12-04 00:28:02', '34a152bc857f168fec31fa257cc9137b', '2023-11-13', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(27, NULL, 'Ken Vic', 'Ken', 'เคน วิค', 'websites@localforyou.com', '-', 'e30d60a4848903ed23c42a8d45eccdba', 1, '16-Ken.png', NULL, 1, '', 2, 10, 5, 4, '2024-01-03 07:22:45', 'e084f50cce419c9f453e1852a31b801c', '2020-01-01', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(28, 'LOC045', 'Watcharaporn Charoenrittikai', 'Mild', 'วัชราภรณ์ เจริญฤทธิไกร', 'mild@localforyou.com', '0938588807', 'e30d60a4848903ed23c42a8d45eccdba', 0, '17-Mild.png', '1996-08-23', 2, '488 ม.7 ซอนดอนอุดม ถนนอำเภอ หมากแข้ง เมือง อุดรธานี 4100', 6, 0, 2, 4, '2024-07-29 13:39:35', '37a90aef9ac874aa8f6dc27d7e50caa1', '2023-03-28', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(29, 'LOC008', 'Warathip Boontuam', 'Mui', 'วราทิพย์ บุญท้วม ', 'mui@localforyou.com', '0992271717', 'e30d60a4848903ed23c42a8d45eccdba', 1, '18-Mui.png', '1999-03-07', 1, '25/15 แม่หาด ต.เกาะเต่า อ.เกาะพะงัน จ.สุราษฎร์ธานี 84360', 1, 5, 4, 3, '2024-01-03 07:05:41', 'd2c9aca080f87b04892e1a6c43e0fb2d', '2023-10-07', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(30, 'LOC029', 'Jutatuch Vichaitanapat', 'Nam', 'จุฑาธุช วิชัยธนพัฒน์', 'nam@localforyou.com', '0924758923', 'e30d60a4848903ed23c42a8d45eccdba', 1, '19-Nam.png', '1994-07-02', 3, '199/338 หมู่ 2 ต.หนองจ๊อม อ.สันทราย จ.เชียงใหม่ 50210', 10, 2, 1, 4, '2024-09-11 20:43:09', 'b53981309888ace4a92ae4c5049fa9d9', '2022-06-20', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(31, 'LOC028', 'Chompunuch Julkraianisong', 'Nan', 'ชมภูนุช จุลไกรอานิสงส์', 'nan@localforyou.com', '0612644636', 'e30d60a4848903ed23c42a8d45eccdba', 1, '20-Nan.png', '1992-06-19', 3, '100/215 หมู่ 3 ต.ไทรม้า อ.เมือง จ.นนทบุรี 11000', 6, 12, 8, 3, '2024-12-04 10:57:06', 'b53d8a83213f142c181242b17ea22bfb', '2022-05-16', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(32, 'LOC017', 'Kingkarn Yuenpairoj', 'Nice', 'กิ่งกาญจน์ ยืนไพโรจน์', 'nice@localforyou.com', '0819937554', 'e30d60a4848903ed23c42a8d45eccdba', 1, '23-Nice.png', '1995-07-03', 1, '', 5, 17, 2, 4, '2024-12-04 12:38:54', '4b286a0acb7cba3faede324bcf6be85c', '2021-12-06', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(33, 'LOC014', 'Pheeraya Tonguamyai', 'Peter', 'พีรยะ ทองอ่วมใหญ่', 'peter@localforyou.com', ' 0826368965', 'e30d60a4848903ed23c42a8d45eccdba', 1, '30-Peter.png', '1997-03-13', 1, '', 10, 0, 2, 4, '2024-09-18 12:36:14', '37b42e6e222e05b59b25158b941330f2', '2021-10-04', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(34, 'LOC039', 'Salilla Wattanapannasorn', 'Piano', 'สลิลลา วัธนพรรณศร', 'piano@localforyou.com', '0813898959', 'e30d60a4848903ed23c42a8d45eccdba', 1, '32-Piano.png', '1991-04-18', 1, '19/165 หมู่บ้านในฝัน1,2 ถ.เทศบาล5 ต.ปากเพรียว อ.เมือง จ.สระบุรี 18000', 62, 0, 2, 4, '2024-12-04 00:29:18', 'dafd88a340c164c34d4b4d3eb5310bc6', '2023-01-04', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(35, 'LOC031', 'Wimol Pluemkamol', 'Pluem', 'วิมล ปลื้มกมล', 'pluem@localforyou.com', '0955627852', 'e30d60a4848903ed23c42a8d45eccdba', 1, '33-Pluem.png', '1998-01-23', 4, '13/164 ป็อปปูล่าคอนโด คอนโด ที4 เมืองทองธานี บ้านใหม่ ปากเกร็ด นนทบุรี 11120', 4, 10, 3, 4, '2024-08-16 12:45:25', '904d46b6ad155e25e962c662f4ed3b4d', '2022-09-19', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(36, 'LOC051', 'Nantaporn Pimsuwan', 'Pookie', 'นันทพร พิมพ์สุวรรณ', 'pookie@localforyou.com', '0633625512', 'e30d60a4848903ed23c42a8d45eccdba', 1, '34-Pookie.png', '1995-06-13', 4, '51 ถนนศิริมังคลาจารย์ ตำบล สุเทพ อำเภอเมือง เชียงใหม่ 50200', 8, 0, 1, 4, '2024-09-11 14:56:21', '95c7a04f8ef055c11c5afaff62454f4a', '2023-08-01', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(37, 'LOC023', 'Panita Phueksapanachat', 'Porsche', 'พนิตา พฤกษาพนาชาติ', 'porsche@localforyou.com', '0869219454', 'e30d60a4848903ed23c42a8d45eccdba', 1, '35-Porsche.png', '1997-07-18', 1, '', 6, 0, 1, 4, '2024-02-14 09:46:30', 'e86bc183aff5e034408944dfb8addf2f', '2022-01-04', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(38, 'LOC058', 'Pruek Patipatsinlapakit', 'Pruek', 'พฤกษ์ ปฏิพัทธศิลปกิจ', 'pruek@localforyou.com', '0908910707', 'e30d60a4848903ed23c42a8d45eccdba', 1, '36-Pruek.png', '1999-02-06', 3, '94/273 เพอร์เฟคพาร์ค ตำบล บางตะไนย์ ถนน หอการค้าไทย ตำบลปากเกร็ด นนทบุรี 11200', 20, 3, 3, 4, '2024-11-08 16:59:52', 'fbc266ccd3a3e28efde20ad2620705bc', '2023-10-09', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(39, 'LOC055', 'Surattana Haoboon', 'Pun', 'สุรัฐณา เฮ่าบุญ', 'pun@localforyou.com', '0950305926', 'e30d60a4848903ed23c42a8d45eccdba', 1, '37-Pun.png', '1997-06-27', 3, '434 ซอยคุ้มเกล้า59 ถนนฉลองกรุง แขวงลำปลาทิว เขตลาดกระบัง กรุงเทพ 10520', 31, 0, 2, 4, '2024-12-04 00:24:27', '9105b1fb20da5d3b79fb68458a5bbfaf', '2023-09-25', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(40, NULL, 'Rhig Macareal', 'Rhig', NULL, 'rhig@localforyou.com', '-', 'e30d60a4848903ed23c42a8d45eccdba', 0, '38-Rhig.png', '2024-01-27', 1, '', 0, 0, 5, 4, '2024-01-03 07:22:31', 'c79bb4490fce94fb871a59083276484d', '2020-01-01', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(41, 'LOC048', 'Jutatip Kankaew', 'Sai', 'จุฑา', 'sai@localforyou.com', '0948068740', 'e30d60a4848903ed23c42a8d45eccdba', 1, '40-Sai.png', '1996-01-09', 3, '112 หมู่', 159, 0, 1, 4, '2024-12-04 12:08:46', '37b5a3beacdf19e99e52593890b7d0ab', '2023-04-03', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(42, 'LOC002', 'Papawadee La-ongnual', 'San', 'ปภาวดี ละอองนวล', 'san@localforyou.com', '0654455615', 'e30d60a4848903ed23c42a8d45eccdba', 1, '41-San.png', '1994-01-04', 1, '', 1, 4, 2, 3, '2024-12-04 11:21:12', '3ceaadf0765c81e27ba75438e8b97bdf', '2019-08-05', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(43, 'LOC041', 'Phatsara Khachornpob', 'Sol', 'ภัสสรา ขจรภพ', 'sol@localforyou.com', '0904992616', 'e30d60a4848903ed23c42a8d45eccdba', 0, '42-Sol.png', '1996-04-02', 3, '', 1, 0, 2, 4, '2024-01-13 02:23:40', '60538e425f91babc254ba8ef6cee3381', '2023-02-06', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(44, NULL, 'Steven Fazakerley', 'Stef', 'สตีฟ ฟาซาเคอรเล่', 'steve@localforyou.com', '61402054030', 'e30d60a4848903ed23c42a8d45eccdba', 1, '43-Stef.png', NULL, 4, '', 1, 0, 6, 1, '2024-01-03 07:10:50', '9cfb808445713702e930dece7d9dd39a', '2019-01-07', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(45, NULL, 'Steven Waterson', 'Steve', 'สตีฟ วอเตอร์สัน', 'stevew@localforyou.com', '-', 'e30d60a4848903ed23c42a8d45eccdba', 1, '44-Steve.png', NULL, 4, '', 1, 0, 6, 1, '2024-01-29 09:37:00', 'b49b2945ae62f11b15bc288e9a0c35b7', '2019-01-07', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(46, 'LOC044', 'Suwattana Panchapornudomlap', 'Tan', 'สุวัฒนา ปัญจพรอุดมลาภ', 'tan@localforyou.com', '0973106026', 'e30d60a4848903ed23c42a8d45eccdba', 1, '45-Tan.png', '1993-10-24', 3, '353/53 พิมาณบุรีบ้านทุ่ม อำเภอเมือง จังหวัดขอนแก่น 40000', 136, 0, 1, 4, '2024-12-03 17:17:38', '867e80242899398d8c5bc52929670657', '2023-03-23', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(47, 'LOC047', 'Mananya Phamonphon', 'Toffee', 'มณัญญา พมรพล', 'toffee@localforyou.com', '0982897470', 'e30d60a4848903ed23c42a8d45eccdba', 0, '46-Toffee.png', '2000-11-06', 4, '505/61 หมู่บ้านเออร์เบิลไลฟ์ ต.ไร่น้อย อ.เมือง จ.อุบลราชธานี 34000 ', 1, 0, 3, 4, '2024-01-03 07:12:03', 'eeab93d695b3b3f66c084465c1003c60', '2023-04-03', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(48, NULL, 'Vance De Guzman', 'Vance', 'แวนซ์ ดิ กุสแมน', 'developer@localforyou.com', '-', 'e30d60a4848903ed23c42a8d45eccdba', 1, '47-Vance.png', NULL, 1, '', 2, 0, 5, 4, '2024-01-03 07:23:20', 'c3538bc4c1aee239d73f7ae89f38e517', '2020-01-01', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(49, 'LOC001', 'Nattiya Joyem', 'Yok', 'นัฐิญา จ้อยเอม', 'nattiya@localforyou.com', '0969875675', 'e30d60a4848903ed23c42a8d45eccdba', 1, '48-Yok.png', '1994-04-25', 4, '', 1, 0, 4, 2, '2024-10-21 14:54:37', '8a4859610170240cd1103367d8ea7405', '2019-01-07', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(50, 'LOC057', 'Pattaranun Lim-olansuksakul', 'Yoou', 'ภัทรนันท์ ลิ้มโอฬารสุขสกุล', 'yoou@localforyou.com', '0993179797', 'e30d60a4848903ed23c42a8d45eccdba', 1, '49-Yoou.png', '1992-01-13', 3, '120/179 หมู่1 ต.บึงยี่โถ อ.ธัญบุรี จ.ปทุมธานี 12130', 2, 3, 5, 4, '2024-12-03 17:54:10', 'bc7dc9013fbb174cbc2f07072bab3575', '2023-10-04', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(51, 'LOC025', 'Thanjira Sirawongjaroen', 'Cindy', 'ธัณย์จิรา สิรวงศ์เจริญ', 'cindy@localforyou.com', '0991985619', 'e30d60a4848903ed23c42a8d45eccdba', 0, 'nopic.png', '1994-07-05', 3, '242 ซ.รังสิต-ปทุมธานี21 ต.ประชาธิปัตย์ อ.ธัญบุรี จ.ปทุมธานี 12130', 0, 0, 1, 4, NULL, NULL, '2022-04-18', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(52, 'LOC034', 'Jutamat Suksri', 'Jane', 'จุฑามาศ สุขศรี', 'jane@localforyou.com', '0823679098', 'e30d60a4848903ed23c42a8d45eccdba', 0, 'nopic.png', '1993-09-07', 3, '4/256 โกสุมสมัคคี 2 เขตดอนเมือง แขวงดอนเมือง กรุงเทพมหานคร 10210', 0, 0, 1, 4, NULL, NULL, '2022-10-24', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(53, 'LOC036', 'Boonsita Tantanarat', 'Mai', 'บุญสิตา ตันตนะรัตน์', 'mai@localforyou.com', '0911421221', 'e30d60a4848903ed23c42a8d45eccdba', 0, 'nopic.png', '1998-01-25', 3, 'หมู่บ้านพฤกษาวิลเลจ1 31/95 ม.17 ต.บึงคำพร้อย อ.ลำลูกกา จ.ปทุมธานี 12150', 0, 0, 1, 4, NULL, NULL, '2022-11-14', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(54, NULL, 'Sermcharoenkit', 'Manow', NULL, 'manow@localforyou.com', '-', 'e30d60a4848903ed23c42a8d45eccdba', 0, 'nopic.png', NULL, 1, '', 0, 0, 2, 4, NULL, NULL, '2020-01-01', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(55, 'LOC038', 'Sutthida Ranob', 'Nicky', 'สุทธิดา ระนบ', 'nicky@localforyou.com', '0802232493', 'e30d60a4848903ed23c42a8d45eccdba', 0, 'nopic.png', '1995-08-05', 3, '63 ม.7 ต.หนองจอก อ.ท่ายาง จ.เพชรบุรี 76130', 0, 0, 1, 4, NULL, NULL, '2023-01-04', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(56, NULL, 'Suwansri', 'Noom', NULL, 'noom@localforyou.com', '-', 'e30d60a4848903ed23c42a8d45eccdba', 0, 'nopic.png', NULL, 1, '', 0, 0, 1, 4, NULL, NULL, '2020-01-01', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(57, NULL, 'Amy', 'Amy', NULL, 'amy@localforyou.com', '-', 'e30d60a4848903ed23c42a8d45eccdba', 0, 'nopic.png', NULL, 1, '', 0, 0, 4, 4, NULL, NULL, '2020-01-01', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(58, 'LOC035', 'Liew', 'Liew', 'ขนิษฐา เลิศรัชตากร', 'liew@localforyou.com', '0971701701', 'e30d60a4848903ed23c42a8d45eccdba', 0, 'nopic.png', '1988-10-21', 4, '7/84 หมู่ที่ 2 หมู่บ้านติวานนท์ ตำบลบางพูด อำเภอปากเกร็ด จังหวัดนนทบุรี 11120', 0, 0, 7, 4, NULL, NULL, '2022-11-23', 1, '2023-12-21 22:20:40', NULL, NULL, NULL, NULL),
(60, 'LOC063', 'Netipong Choosri', 'Mark', 'เนติพงศ์ ชูศรี', 'mark@localforyou.com', '0944081919', '1feec1dfe489d7c6de4bd93275f2cdf0', 1, '52-Mark.png', '1996-01-20', 1, 'B31 86/167 ซ.เพิ่มสุข ถ.กาญจนาภิเษก ต.บางคูเวียง อ.บางกรวย จ.นนทบุรี 11130', 2, 0, 5, 4, '2024-12-04 11:32:42', '2186aaf4153927f54e29b100b1d11a9f', '2024-03-10', 1, '2024-04-17 11:30:51', NULL, 1, NULL, NULL),
(61, 'LOC061', 'Arriya Deewan', 'Eve', 'อารียา ดีวัน', 'eve@localforyou.com', '0840286963', '35d3f3a0f752f01118028849afdf3c08', 1, '54-Eve.png', '1999-02-11', 3, '588/149 ม.5 ชลพฤกษ์ พาร์ควิลล์ ต.เมืองเก่า อ.เมือง จ.ขอนแก่น 40000', 4, 0, 3, 4, '2024-04-18 15:16:38', '9db7688df25c94ca41db6ae05a2f63b3', '2024-03-04', 1, '2024-04-17 16:03:08', NULL, 1, NULL, NULL),
(62, 'LOC062', 'Anirut Jirasirinanthachai', 'Ball', 'อนิรุตมิ์ จิราสิรินันทชัย', 'ball@localforyou.com', '0958090837', '35d3f3a0f752f01118028849afdf3c08', 1, '53-Ball.png', '2000-05-17', 3, '44/41 หมู่ 2 ต.บางพูด อ.ปากเกร็ด จ.นนทบุรี', 4, 10, 3, 4, '2024-12-04 13:23:37', '61ddb07b501896eccac11f60ed35a253', '2024-03-04', 1, '2024-04-17 16:03:08', NULL, 1, NULL, NULL),
(63, 'LOC064', 'Pitchaya Phetpinit', 'Patty', 'พิชญา เพชรพินิจ', 'patty@localforyou.com', '0985801772', '35d3f3a0f752f01118028849afdf3c08', 1, '51-Patty.png', '1999-03-02', 3, '248/59 ถ.ทุ่งโฮเต็ล ซ.4 ต.วัดเกต อ.เมืองเชียงใหม่ จ.เชียงใหม่ 5000', 1, 0, 10, 4, '2024-04-18 15:17:29', '058cab5e2ea972667734625eb1b0aae8', '2024-04-01', 1, '2024-04-17 16:03:08', NULL, 1, NULL, NULL),
(64, 'LOC066', 'Nichakorn Muneeapiban', 'Nicha', 'ณิชากร มุนีอภิบาล', 'nicha@localforyou.com', '0803829785', '35d3f3a0f752f01118028849afdf3c08', 1, '49-Nicha.png', '1997-12-07', 3, '90/13 ม.7 ต. หัวเขา อ. สิงหนคร จ. สงขลา 90280', 101, 0, 10, 4, '2024-12-04 12:09:18', 'a2badc2541411bef279973b43ef02cce', '2024-04-01', 1, '2024-04-18 11:13:40', NULL, 1, NULL, NULL),
(65, 'LOC065', 'Janisata Lertumpornpitak', 'Valentine', 'จณิสตา เลิศอัมพรพิทักษ์', 'valentine@localforyou.com', '0803514273', '35d3f3a0f752f01118028849afdf3c08', 1, '50-Valentine.png', '1998-02-14', 4, 'แฟลชโฮมสงขลา หมู่บ้านเดอะซิตี้ \r\n100/53 ม.1 ต.พะวง อ.เมือง  จ.สงขลา \r\n90100', 8, 2, 8, 4, '2024-04-18 23:19:20', '51c254422c7b611359aa07913c4eb026', '2024-04-01', 1, '2024-04-18 11:17:22', NULL, 1, NULL, NULL),
(66, 'LOC045', 'Sirinda Jangsuthivorawat', 'Giffy', 'สิรินดา แจ้งสุทธิวรวัฒน์', 'giffy@localforyou.com', '0877986232', '35d3f3a0f752f01118028849afdf3c08', 0, 'no_pic.png', '1996-08-23', 2, '89/423 หมู่บ้านเพอร์เฟคพาร์ค-พระราม5 บางใหญ๋ ซอยวัดส้มเกลี้ยง ตำบลบางแม่นาง อำเภอบางใหญ่ นนทบุรี 11140', 0, 0, 2, 4, NULL, NULL, '2024-10-21', 1, '2024-11-08 22:20:40', NULL, NULL, NULL, NULL);

DROP TABLE IF EXISTS `StatsMeasureDetail`;
CREATE TABLE `StatsMeasureDetail` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `typeID` tinyint(3) UNSIGNED NOT NULL,
  `month` enum('01','02','03','04','05','06','07','08','09','10','11','12') NOT NULL,
  `year` year(4) NOT NULL,
  `total` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `StatsMeasureDetail` (`id`, `typeID`, `month`, `year`, `total`) VALUES
(1, 1, '01', '2023', 150.12),
(4, 2, '03', '2023', 123.45),
(5, 3, '03', '2023', 453.98),
(6, 4, '02', '2023', 289.25),
(7, 2, '04', '2023', 1023.12),
(9, 1, '07', '2023', 110.56),
(10, 1, '10', '2023', 123.45),
(11, 2, '10', '2023', 234.56),
(13, 1, '07', '2022', 250),
(14, 1, '09', '2022', 11.2),
(15, 5, '10', '2023', 11),
(18, 2, '11', '2023', 1111);

DROP TABLE IF EXISTS `StatsMeasureType`;
CREATE TABLE `StatsMeasureType` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `StatsMeasureType` (`id`, `name`, `status`) VALUES
(1, 'Churn Rate', 1),
(2, 'Downgrade Rate', 1),
(3, 'Cancellation Revenue Lost', 1),
(4, 'Cost of Acquisition p/Unit', 1),
(5, 'Ads/Marketing Fees', 1),
(6, 'Sales Signup Revenue (pay upfront)', 1),
(7, 'Bad Debt (Arrears in Cancellation Stage)', 1);

DROP TABLE IF EXISTS `Subscriptions`;
CREATE TABLE `Subscriptions` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `service` varchar(255) NOT NULL,
  `value` float NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `Subscriptions` (`id`, `service`, `value`, `status`) VALUES
(1, '112forSMScredits', 139, 1),
(2, '360SMS', 96, 1),
(3, 'EzyHR', 12, 1),
(4, 'Google suite', 16.12, 1),
(5, 'Jobsdb', 21.54, 1),
(6, 'Line', 153.2, 1),
(7, 'Microsoft', 21.23, 1),
(8, 'Myinterview', 110.41, 1),
(9, 'Respond IO', 53.51, 1),
(10, 'Salesforce', 21.07, 1),
(11, 'Trainual', 54.52, 1),
(12, 'Youcanbookme', 462.01, 1),
(13, 'Zoom', 21.32, 1);

DROP TABLE IF EXISTS `SucscriptionsMonthly`;
CREATE TABLE `SucscriptionsMonthly` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `typeID` tinyint(3) UNSIGNED NOT NULL,
  `month` enum('01','02','03','04','05','06','07','08','09','10','11','12') NOT NULL,
  `year` year(4) NOT NULL,
  `value` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `SucscriptionsMonthly` (`id`, `typeID`, `month`, `year`, `value`) VALUES
(1, 2, '08', '2023', 23),
(2, 2, '09', '2023', 25.12),
(3, 2, '10', '2023', 25.12),
(4, 3, '07', '2023', 116),
(5, 3, '08', '2023', 116),
(6, 3, '09', '2023', 120.25),
(7, 3, '10', '2023', 153.32),
(8, 4, '09', '2023', 12.25),
(9, 4, '10', '2023', 15.55),
(10, 5, '09', '2023', 132.25),
(11, 5, '10', '2023', 157.55),
(12, 12, '10', '2023', 123),
(14, 7, '10', '2023', 543);

DROP TABLE IF EXISTS `SucscriptionsType`;
CREATE TABLE `SucscriptionsType` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `period` enum('Monthly','Yearly') NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `SucscriptionsType` (`id`, `name`, `period`, `status`) VALUES
(1, 'Microsoft', 'Yearly', 1),
(2, 'Youcanbookme 112forSMScredits', 'Monthly', 1),
(3, 'Zoom', 'Monthly', 1),
(4, 'Respond IO', 'Monthly', 1),
(5, 'Salesforce ', 'Monthly', 1),
(6, 'Myinterview ', 'Yearly', 1),
(7, 'Line', 'Monthly', 1),
(8, 'EzyHR', 'Yearly', 1),
(9, 'Jobsdb', 'Monthly', 1),
(10, 'Trainual', 'Yearly', 1),
(11, 'Google G Suite', 'Monthly', 1),
(12, '360 SMS', 'Monthly', 1);

DROP TABLE IF EXISTS `SucscriptionsYearly`;
CREATE TABLE `SucscriptionsYearly` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `typeID` tinyint(3) UNSIGNED NOT NULL,
  `year` year(4) NOT NULL,
  `value` float UNSIGNED NOT NULL,
  `paidOn` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `SucscriptionsYearly` (`id`, `typeID`, `year`, `value`, `paidOn`) VALUES
(1, 1, '2023', 256.35, '2023-10-30 12:07:11'),
(2, 6, '2023', 256.35, '2023-10-30 12:07:11'),
(3, 8, '2021', 245.35, '2023-10-30 12:07:11'),
(4, 8, '2022', 245.35, '2023-10-30 12:07:11'),
(5, 8, '2023', 245.35, '2023-10-30 12:07:11'),
(6, 10, '2021', 126.11, '2023-10-30 12:07:11'),
(7, 10, '2022', 126.11, '2023-10-30 12:07:11'),
(8, 10, '2023', 126.11, '2023-10-30 12:07:11');

DROP TABLE IF EXISTS `SupportLanguage`;
CREATE TABLE `SupportLanguage` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `SupportLanguage` (`id`, `name`, `value`, `status`) VALUES
(1, 'English', 'English', 1),
(2, 'Thai', 'Thai', 1),
(3, 'English & Thai', 'English and Thai', 1);

DROP TABLE IF EXISTS `tb_country`;
CREATE TABLE `tb_country` (
  `countryID` int(11) NOT NULL,
  `countryName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_country` (`countryID`, `countryName`) VALUES
(1, 'Austaralia'),
(2, 'New Zealand'),
(3, 'United Kingdom'),
(4, 'United States');

DROP TABLE IF EXISTS `tb_images`;
CREATE TABLE `tb_images` (
  `imagesID` int(11) NOT NULL,
  `projectID` int(10) UNSIGNED NOT NULL,
  `imagesName` text NOT NULL,
  `imagesTimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `tb_page`;
CREATE TABLE `tb_page` (
  `pageID` int(11) NOT NULL,
  `pageName` varchar(255) NOT NULL,
  `pagePoint` int(100) UNSIGNED NOT NULL,
  `pageContent` text NOT NULL,
  `imagesName` text NOT NULL COMMENT 'tb_images',
  `imagesTimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `projectID` int(100) DEFAULT NULL COMMENT 'projectID tb_project ,tb_templatedetail , tb_page'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `tb_project`;
CREATE TABLE `tb_project` (
  `projectID` tinyint(4) NOT NULL,
  `projectName` varchar(255) NOT NULL,
  `shopTypeID` tinyint(1) UNSIGNED NOT NULL DEFAULT 1,
  `countryID` tinyint(3) UNSIGNED NOT NULL COMMENT 'CountryID',
  `statusID` tinyint(3) UNSIGNED NOT NULL COMMENT 'StatusID',
  `projectTimestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `projectOwner` int(10) UNSIGNED NOT NULL COMMENT 'sID from table staffs'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_project` (`projectID`, `projectName`, `shopTypeID`, `countryID`, `statusID`, `projectTimestamp`, `projectOwner`) VALUES
(1, 'me11', 1, 2, 2, '2024-04-16 14:25:48', 28),
(2, 'atomix', 1, 2, 2, '2024-04-16 14:25:42', 28),
(3, 'element', 1, 2, 2, '2024-04-16 14:25:38', 28),
(4, 'good food', 1, 1, 2, '2024-04-16 14:26:00', 28),
(5, 'superman', 1, 2, 2, '2024-04-15 08:25:45', 28),
(6, 'mark', 1, 1, 1, '2024-04-16 15:45:59', 28),
(7, 'goodman', 1, 3, 2, '2024-08-05 07:29:04', 1),
(8, 'Bad Man', 1, 4, 2, '2024-04-16 15:20:17', 26),
(9, 'Bad Man', 1, 4, 2, '2024-04-16 15:20:17', 26),
(10, 'Bad Man', 1, 4, 2, '2024-04-16 15:20:17', 26),
(11, 'takrit', 1, 4, 2, '2024-08-05 07:28:56', 1),
(12, '#tak\"rit', 1, 4, 2, '2024-04-16 15:06:36', 26),
(13, '#tak\"irt', 1, 1, 2, '2024-04-16 15:07:49', 19),
(14, 'it\'s_thai', 1, 4, 2, '2024-04-16 15:08:59', 26),
(15, 'it\'s_thai', 1, 4, 2, '2024-04-16 15:14:55', 26),
(16, 'wwwwww', 1, 0, 1, '2024-07-31 01:06:39', 1),
(17, 'good project', 1, 0, 1, '2024-07-31 01:21:23', 14),
(18, 'qwewewewewqe', 1, 0, 1, '2024-07-31 01:25:35', 1),
(19, 'foot restaurant', 1, 0, 1, '2024-07-31 01:26:29', 14),
(20, 'Test1', 1, 0, 1, '2024-07-31 01:29:29', 60),
(21, 'Test3107-1', 1, 0, 1, '2024-07-31 01:36:49', 60),
(22, 'Test3107-1', 1, 0, 1, '2024-07-31 01:40:12', 60),
(23, 'Test3107-1', 1, 0, 1, '2024-07-31 01:41:41', 60),
(24, 'Test3107-1', 1, 0, 1, '2024-07-31 02:13:23', 60),
(25, 'Test3107-1', 1, 0, 1, '2024-07-31 02:27:56', 60),
(26, 'Test3107-1', 1, 0, 1, '2024-07-31 02:28:50', 60),
(27, 'Test3107-1', 1, 0, 1, '2024-07-31 02:30:23', 60),
(28, 'Test3107-1', 1, 0, 1, '2024-07-31 02:32:49', 60),
(29, 'Test3107-1', 1, 0, 1, '2024-07-31 02:34:57', 60),
(30, 'Test3107-1', 1, 0, 1, '2024-07-31 02:39:48', 60),
(31, 'Test3107-1', 1, 0, 1, '2024-07-31 02:51:14', 60);

DROP TABLE IF EXISTS `tb_shopType`;
CREATE TABLE `tb_shopType` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `tb_shopType` (`id`, `name`, `create_at`, `update_at`) VALUES
(1, 'Restaurant', '2024-09-09 23:48:17', NULL),
(2, 'Massage', '2024-09-09 23:48:17', NULL);

DROP TABLE IF EXISTS `tb_status`;
CREATE TABLE `tb_status` (
  `statusID` tinyint(3) UNSIGNED NOT NULL,
  `statusName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_status` (`statusID`, `statusName`) VALUES
(1, 'Send'),
(2, 'Draft');

DROP TABLE IF EXISTS `tb_system`;
CREATE TABLE `tb_system` (
  `systemID` int(11) NOT NULL,
  `systemName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_system` (`systemID`, `systemName`) VALUES
(1, 'Amelia'),
(2, 'Gloriafood');

DROP TABLE IF EXISTS `tb_templatedetail`;
CREATE TABLE `tb_templatedetail` (
  `tdID` int(11) NOT NULL,
  `projectID` int(10) UNSIGNED NOT NULL,
  `tdShoptype` varchar(15) NOT NULL,
  `tdTemplate` tinyint(3) UNSIGNED NOT NULL,
  `tdColor` varchar(40) NOT NULL,
  `tdEmail` varchar(255) NOT NULL,
  `tdAddress` text NOT NULL,
  `countryID` int(11) NOT NULL,
  `tdPhone` varchar(20) NOT NULL,
  `tdGGreview` text NOT NULL,
  `tdOrder` varchar(200) NOT NULL,
  `tdTable` varchar(200) NOT NULL,
  `tdOpening` text NOT NULL,
  `tdSocial` varchar(255) NOT NULL,
  `systemID` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_templatedetail` (`tdID`, `projectID`, `tdShoptype`, `tdTemplate`, `tdColor`, `tdEmail`, `tdAddress`, `countryID`, `tdPhone`, `tdGGreview`, `tdOrder`, `tdTable`, `tdOpening`, `tdSocial`, `systemID`) VALUES
(1, 3, '', 0, '', '', '', 2, '', '', '', '', '', '', 0),
(2, 3, '', 0, '', '', '', 2, '', '', '', '', '', '', 0),
(3, 3, '', 0, '', '', '', 2, '', '', '', '', '', '', 0),
(4, 3, '', 0, '', '', '', 2, '', '', '', '', '', '', 0),
(5, 3, '', 0, '', '', '', 2, '', '', '', '', '', '', 0),
(6, 3, '', 0, '', '', '', 2, '', '', '', '', '', '', 0);

DROP TABLE IF EXISTS `Team`;
CREATE TABLE `Team` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `idx` tinyint(3) UNSIGNED NOT NULL COMMENT 'index number'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `Team` (`id`, `name`, `fullName`, `idx`) VALUES
(1, 'CS', 'Customer Support', 0),
(2, 'AM AU', 'Account Manager Australia', 1),
(3, 'SE', 'Sale', 5),
(4, 'HR', 'Human Resource', 6),
(5, 'IT', 'Information Technology', 7),
(6, 'CEO', 'Chief Executive Officer', 8),
(7, 'OT', 'Other', 9),
(8, 'AM USA', 'Account Manager USA', 3),
(10, 'AM NZ', 'Account Manager New Zealand', 2),
(11, 'AM UK', 'Account Manager United Kingdom’s', 4);

DROP TABLE IF EXISTS `userLevel`;
CREATE TABLE `userLevel` (
  `lID` tinyint(3) UNSIGNED NOT NULL,
  `lName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `userLevel` (`lID`, `lName`) VALUES
(1, 'Super Admin'),
(2, 'Admin'),
(3, 'Manager'),
(4, 'User');


ALTER TABLE `CoinActivities`
  ADD PRIMARY KEY (`aID`);

ALTER TABLE `CoinLogs`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `CoinType`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `Countries`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `CustomerType`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `Employees`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `ExpenseDetail`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `ExpenseType`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `exp_project`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `IHDDetail`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `IHDType`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `passwordmanager`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `Products`
  ADD PRIMARY KEY (`pID`);

ALTER TABLE `RevenueDetail`
  ADD PRIMARY KEY (`rID`);

ALTER TABLE `rewardcategories`
  ADD PRIMARY KEY (`rcID`);

ALTER TABLE `rewardstype`
  ADD PRIMARY KEY (`rtID`);

ALTER TABLE `SpendLogs`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `SpendType`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `staffs`
  ADD PRIMARY KEY (`sID`);

ALTER TABLE `StatsMeasureDetail`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `StatsMeasureType`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `Subscriptions`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `SucscriptionsMonthly`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `SucscriptionsType`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `SucscriptionsYearly`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `SupportLanguage`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tb_country`
  ADD PRIMARY KEY (`countryID`);

ALTER TABLE `tb_images`
  ADD PRIMARY KEY (`imagesID`);

ALTER TABLE `tb_page`
  ADD PRIMARY KEY (`pageID`);

ALTER TABLE `tb_project`
  ADD PRIMARY KEY (`projectID`);

ALTER TABLE `tb_shopType`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tb_status`
  ADD PRIMARY KEY (`statusID`);

ALTER TABLE `tb_system`
  ADD PRIMARY KEY (`systemID`);

ALTER TABLE `tb_templatedetail`
  ADD PRIMARY KEY (`tdID`);

ALTER TABLE `userLevel`
  ADD PRIMARY KEY (`lID`);


ALTER TABLE `CoinActivities`
  MODIFY `aID` tinyint(4) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

ALTER TABLE `CoinLogs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=319;

ALTER TABLE `CoinType`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `Countries`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `CustomerType`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

ALTER TABLE `Employees`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

ALTER TABLE `ExpenseDetail`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

ALTER TABLE `ExpenseType`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

ALTER TABLE `exp_project`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `IHDDetail`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

ALTER TABLE `IHDType`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `passwordmanager`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

ALTER TABLE `Products`
  MODIFY `pID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

ALTER TABLE `RevenueDetail`
  MODIFY `rID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `rewardcategories`
  MODIFY `rcID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

ALTER TABLE `rewardstype`
  MODIFY `rtID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

ALTER TABLE `SpendLogs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

ALTER TABLE `SpendType`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

ALTER TABLE `staffs`
  MODIFY `sID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

ALTER TABLE `StatsMeasureDetail`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

ALTER TABLE `StatsMeasureType`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

ALTER TABLE `Subscriptions`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

ALTER TABLE `SucscriptionsMonthly`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

ALTER TABLE `SucscriptionsType`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

ALTER TABLE `SucscriptionsYearly`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

ALTER TABLE `SupportLanguage`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `tb_country`
  MODIFY `countryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

ALTER TABLE `tb_images`
  MODIFY `imagesID` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `tb_page`
  MODIFY `pageID` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `tb_project`
  MODIFY `projectID` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

ALTER TABLE `tb_shopType`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `tb_status`
  MODIFY `statusID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `tb_system`
  MODIFY `systemID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `tb_templatedetail`
  MODIFY `tdID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

ALTER TABLE `userLevel`
  MODIFY `lID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
